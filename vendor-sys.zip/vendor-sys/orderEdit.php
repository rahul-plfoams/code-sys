<?php
$orderid = $_GET['orderid'];
define("TITLE", "vendor");
require_once "./admin/nav.php";

$sql = "SELECT * FROM orders WHERE order_id=" . $orderid;
$result = $db->query($sql)->fetch_assoc();
$orderdetails = unserialize($result['order_details']);
?>
<form action="order.php?orderid=<?=$orderid?>" method="post">
    <table id="listProducts" class="table table-bordered table-hover table-sm">
        <thead>
            <tr>
                <td class="justify-content-center p-2">Sr. No</td>
                <td class="iwidth">SKU/Code</td>
                <td>Name</td>
                <td>Grade</td>
                <td>Quality</td>
                <td>Unit</td>
                <td>GST</td>
                <td class="iwidth">Length</td>
                <td class="iwidth">Width</td>
                <td class="iwidth">Thickness</td>
                <td class="iwidth">Quantity</td>
                <td>remark</td>
            </tr>
        </thead>
        <tbody id="ordertable">
        <?php for ($i = 0; $i < count($orderdetails); $i++): ?>
        <tr>
            <td class="align-middle"><?=$i + 1?></td>
            <td class="align-middle"><input class="form-control" type="text"
                    value="<?=$orderdetails[$i]['vendor_code']?>" name="vendor_code[]"></td>
            <?php
$product = "SELECT * FROM vendor_pref INNER JOIN products using(product_id) WHERE vendor_id=" . $_SESSION['user']['id'] . " AND product_id=" . $orderdetails[$i]['product_id'];
$productdetails = $db->query($product)->fetch_assoc();
?>
            <td class="align-middle"><?=$productdetails['product_name']?>
            <input type="hidden" name="product_id[]" value='<?=$orderdetails[$i]['product_id']?>'>
            </td>
            <td class="align-middle"><?=$productdetails['grade']?></td>
            <td class="align-middle"><?=$productdetails['quality']?></td>
            <td class="align-middle"><?=$productdetails['unit']?></td>
            <td class="align-middle"><?=$productdetails['gst_rate']?></td>
            <td class="align-middle"><input class="form-control" type="number" value="<?=$orderdetails[$i]['length']?>" name="length[]">
            </td>
            <td class="align-middle"><input class="form-control" type="number" value="<?=$orderdetails[$i]['width']?>" name="width[]">
            </td>
            <td class="align-middle"><input class="form-control" type="number"
                    value="<?=$orderdetails[$i]['thickness']?>" name="thickness[]"></td>
            <td class="align-middle"><input class="form-control" type="number"
                    value="<?=$orderdetails[$i]['quantity']?>" name="quantity[]"></td>
            <td class="align-middle"><textarea class="form-control" name="remark[]"><?=$orderdetails[$i]['remark']?></textarea></td>
                    </tr>
                    <?php endfor;?>
        </tbody>
    </table>

    <input class="btn btn-success " type="submit" value="Place Order">
    <?php require_once "footer.php"?>