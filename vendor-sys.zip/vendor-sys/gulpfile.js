const {
    src,
    dest,
    parallel,
    series,
    watch
} = require('gulp');
const rename = require('gulp-rename');
const pug = require('gulp-pug');
const sass = require('gulp-sass');


function html() {
    return src('./pug/**/*.pug')
        .pipe(pug({
            pretty: true
        }))
        .pipe(rename({
            extname: '.php'
        }))
        .pipe(dest('./'));
}

function css() {
    return src('./sass/**/*.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(dest('./'));
}

function watchTask() {
    watch('./pug/*.pug', html);
    watch('./sass/*.scss', css);
}

exports.default = series(parallel(html, css), watchTask);