<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'c/9zrEOzeF0-0oD0oVEiONhPIBr0MSB4fm7rPMG1h8');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>