<?php
class Db
{
    private $server = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "vendor_db";
    public function __construct()
    {
        return $this->conn = new mysqli($this->server, $this->username, $this->password, $this->database);
    }
    public function query($query)
    {
        return $this->conn->query($query);
    }

    public function getRow($table)
    {
        $sql = "select * from $table";
        return $this->conn->query($sql)->fetch_assoc();
    }
    public function getRows($table, $limit = '')
    {
        $sql = "select * from $table";
        $result = $this->conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo $row['product_name'];
        }
    }
}
