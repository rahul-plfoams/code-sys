<?php
// date_default_timezone_set('Asia/Kolkata');
session_start();
$vendor_id = $_SESSION['user']['id'];
$vendor_code = $_POST['vendor_code'];
$product_id = $_POST['product_id'];
$length = $_POST['length'];
$width = $_POST['width'];
$thickness = $_POST['thickness'];
$quantity = $_POST['quantity'];
$remark = $_POST['remark'];
$orders = [];
?>
<table>
<thead></thead>
    <tr>
        <td>Vendor Code</td>
        <td>product_id</td>
        <td>length</td>
        <td>width</td>
        <td>thickness</td>
        <td>quantity</td>
        <td>remark</td>
    </tr>
</thead>
<tbody>
<?php for ($i = 0; $i < count($vendor_code); $i++): ?>
<tr>
    <td><?=$vendor_code[$i]?></td>
    <td><?=$product_id[$i]?></td>
    <td><?=$length[$i]?></td>
    <td><?=$width[$i]?></td>
    <td><?=$thickness[$i]?></td>
    <td><?=$quantity[$i]?></td>
    <td><?=$remark[$i]?></td>
</tr>
<?php
$orders[$i]['vendor_code'] = $vendor_code[$i];
$orders[$i]['product_id'] = $product_id[$i];
$orders[$i]['length'] = $length[$i];
$orders[$i]['width'] = $width[$i];
$orders[$i]['thickness'] = $thickness[$i];
$orders[$i]['quantity'] = $quantity[$i];
$orders[$i]['remark'] = $remark[$i];
endfor;?>
    </tbody>
    </table>
<?php
$dborders = serialize($orders);
echo $dborders;
$ordertime = date("Y-m-d H:i:s");
$conn = new mysqli("localhost", "root", "", "vendor_db");
if (isset($_GET['orderid'])) {
    $sql = "UPDATE orders SET order_details='$dborders' WHERE order_id=" . $_GET['orderid'];
    $result = $conn->query($sql);
    if ($result) {header("location:orderEdit.php?orderid=" . $_GET['orderid']);}
} else {
    $sql = "INSERT INTO orders(vendor_id,order_details,order_generated) VALUES($vendor_id,'$dborders','$ordertime')";
    echo $conn->query($sql) ? 'success' : 'failed';
}