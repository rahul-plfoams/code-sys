<?php
$mobile = $_GET['mobile'];
$vendor_id = $_GET['id'];
$conn = new mysqli("localhost", "root", "", "vendor_db");

$result = $conn->query("SELECT * FROM vendor_pref JOIN vendor_details ON vendor_pref.vendor_id=vendor_details.id LEFT JOIN products ON vendor_pref.product_id=products.product_id where vendor_id=$vendor_id");

?>
<style>
table,td{
    border:1px solid grey;
    border-collapse:collapse;
}
</style>
<table>
    <thead>
        <tr>
            <td>Sr. No</td>
            <td>Name</td>
            <td>Grade</td>
            <td>Quality</td>
            <!-- <td>Rate</td>
            <td>Unit</td>
            <td>GST</td> -->
            <td>remark</td>
        </tr>
    </thead>
    <tbody>
    <?php
$sr = 1;
while ($row = $result->fetch_assoc()): ?>
    <tr>
    <td><?=$sr?></td>
    <td><?=$row['product_name']?></td>
    <td><?=$row['grade']?></td>
    <td><?=$row['quality']?></td>
    <!-- <td><?=$row['product_rate']?></td>
    <td><?=$row['unit']?></td>
    <td><?=$row['gst_rate']?></td> -->
    <td><?=$row['product_remark']?></td>
    </tr>
    <?php
$sr++;
endwhile?>
    </tbody>
</table>