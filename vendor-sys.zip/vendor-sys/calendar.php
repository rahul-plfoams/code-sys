<?php
include('functions.php');
                 $fromDate = $_GET['fromDate'];
                 $toDate = $_GET['toDate'];
                // starts
                $get_details1="SELECT * FROM ledger_data WHERE date BETWEEN '".$fromDate."' AND '".$toDate."' AND id=".$_SESSION['user']['id']." order by date desc";
                $result1=$db->query($get_details1);
                
                while($row = mysqli_fetch_array($result1)) {
                    echo "<tr>";
                    echo "<td>" . $row['date'] . "</td>";
                    echo "<td>" . $row['particulars'] . "</td>";
                    echo "<td>" . $row['remark'] . "</td>";
                    echo "<td>" . $row['voucher_type'] . "</td>";
                    echo "<td>" . $row['voucher_no'] . "</td>";
                    echo "<td>" . $row['debit'] . "</td>";
                    echo "<td>" . $row['credit'] . "</td>";
                    echo "</tr>";
                }
                ?>