<script
  src="https://code.jquery.com/jquery-3.4.1.slim.min.js">	
</script>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  margin: 0 auto;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
  width: 150px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #5f9ea0;
  color: white;
}

.btnBlueGreen.btnPush {
  box-shadow: 0px 5px 0px 0px #607D8B;
}
.btnPush:hover {
  margin-top: 15px;
  margin-bottom: 5px;
}

.btnBlueGreen.btnPush:hover {
  box-shadow: 0px 0px 0px 0px #607D8B;
}
button {
  display: block;
  position: relative;
  float: left;
  width: 120px;
  padding: 0;
  margin: 10px 20px 10px 0;
  font-weight: 600;
  text-align: center;
  line-height: 40px;
  color: #FFF;
  border-radius: 20px;
  transition: all 0.2s ;
  outline: none;
}
.btnBlueGreen {
    background: #5f9ea0;
}
</style>
<style>
	#billing_address,
	#shipping_address,
	#contact,
	#gst,
	#products,
	#ledger {
		display: none;
	}
</style>

<style>
	.customers {
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		margin: 0 auto;
		width: 100%;
	}

	.customers td,
	.customers th {
		border: 1px solid #ddd;
		padding: 8px;
		width: 150px;
	}

	.customers tr:nth-child(even) {
		background-color: #f2f2f2;
	}

	.customers tr:hover {
		background-color: #ddd;
	}

	.customers th {
		padding-top: 12px;
		padding-bottom: 12px;
		text-align: left;
		background-color: #5f9ea0;
		color: white;
	}

	.btnBlueGreen.btnPush {
		box-shadow: 0px 5px 0px 0px #607D8B;
	}

	.btnPush:hover {
		margin-top: 15px;
		margin-bottom: 5px;
	}

	.btnBlueGreen.btnPush:hover {
		box-shadow: 0px 0px 0px 0px #607D8B;
	}

	button {
		display: block;
		position: relative;
		float: left;
		width: 125px;
		padding: 0;
		margin: 10px 20px 10px 0;
		font-weight: 600;
		text-align: center;
		line-height: 40px;
		color: #FFF;
		border-radius: 20px;
		transition: all 0.2s;
		outline: none;
	}

	.btnBlueGreen {
		background: #5f9ea0;
	}

	/*product tab style starts*/
	#products>td,
	td input {
		max-width: 8vw;
	}
	.chooseFileTd{
		text-align: center;
	}
	.chooseFileInput{
		max-width: none;
		padding: 25px;
	}

	/*product tab style ends*/

</style>
<style>
/* Style the active class, and buttons on mouse-over */
.active, .btnArrow:hover {
  background-color: #7dda11;
  color: white;
}

input[readonly] {
background-color: silver;
}
</style>

<?php
include 'conn.php';
include_once('E:\test2\vendor new\vendor-login\functions.php');
session_start();
$id = $_GET['id'];

$view = "SELECT * from users where id = '$id'";
$row = $conn->query($view)->fetch_assoc();

$vendor_details="SELECT * FROM vendor_details where id='".$id."'";
$details_result=$conn->query($vendor_details)->fetch_assoc();

if(isset($_POST['update'])){

	$fn = $_POST['fname'];
	$ln = $_POST['lname'];
	$name = $_POST['name'];
	$company_name = $_POST['company_name'];
	$password_1 = $_POST['password_1'];
	$password = md5($password_1);//encrypt the password before saving in the database

	$address = $_POST['address'];
	$place = $_POST['place'];
	$pincode = $_POST['pincode'];
	$state = $_POST['state'];
	$country = $_POST['country'];
	$credit_days = $_POST['credit_days'];
	$credit_limit = $_POST['credit_limit'];
	$kilometer = $_POST['kilometer'];

	$billing_address = $_POST['billing_address'];
	$billing_place = $_POST['billing_place'];
	$billing_pincode = $_POST['billing_pincode'];
	$billing_state = $_POST['billing_state'];
	$billing_country = $_POST['billing_country'];
	$billing_credit_days = $_POST['billing_credit_days'];
	$billing_credit_limit = $_POST['billing_credit_limit'];
	$billing_kilometer = $_POST['billing_kilometer'];
	
	$phone = $_POST['phone'];
	$mobile = $_POST['mobile'];
	$email = $_POST['email'];
	$website = $_POST['website'];
	$reference = $_POST['reference'];
	$owner = $_POST['owner'];
	$gst_place = $_POST['gst_place'];
	$state_code = $_POST['state_code'];
	$gst_no = $_POST['gst_no'];
	$account_no = $_POST['account_no'];
	$bank_name = $_POST['bank_name'];
	$account_type = $_POST['account_type'];
	$ifsc = $_POST['ifsc'];
	$branch = $_POST['branch'];

	$description_of_goods = $_POST['description_of_goods'];
	$grade = $_POST['grade'];
	$quality = $_POST['quality'];
	$rate_per_mm = $_POST['rate_per_mm'];
	$rate_per_kg = $_POST['rate_per_kg'];
	$rate_per_sqft = $_POST['rate_per_sqft'];
	$rate_per_mtr = $_POST['rate_per_mtr'];
	$rate_per_pcs = $_POST['rate_per_pcs'];
	$gst_rate = $_POST['gst_rate'];
	$hsn = $_POST['hsn'];

	$insert = "UPDATE users set username = '$fn', user_type = '$ln', name = '$name', password = '$password' where id = '$id'";

	$insert1 = "UPDATE vendor_details SET company_name = '".$company_name."', address = '".$address."', place = '".$place."', pincode = '".$pincode."', state = '".$state."', country = '".$country."', credit_days = '".$credit_days."', credit_limit = '".$credit_limit."', kilometer = '".$kilometer."', billing_address = '".$billing_address."', billing_place = '".$billing_place."', billing_pincode = '".$billing_pincode."', billing_state = '".$billing_state."', billing_country = '".$billing_country."', billing_credit_days = '".$billing_credit_days."', billing_credit_limit = '".$billing_credit_limit."', billing_kilometer = '".$billing_kilometer."', phone = '".$phone."', mobile = '".$mobile."', email = '".$email."', website = '".$website."', reference = '".$reference."', owner = '".$owner."', gst_place = '".$gst_place."', state_code = '".$state_code."', gst_no = '".$gst_no."', account_no = '".$account_no."', bank_name = '".$bank_name."', account_type = '".$account_type."', ifsc = '".$ifsc."', branch = '".$branch."', description_of_goods = '".$description_of_goods."',grade = '".$grade."',quality = '".$quality."',rate_per_mm = '".$rate_per_mm."',rate_per_kg = '".$rate_per_kg."',rate_per_sqft = '".$rate_per_sqft."',rate_per_mtr = '".$rate_per_mtr."',rate_per_pcs = '".$rate_per_pcs."',gst_rate = '".$gst_rate."',hsn = '".$hsn."' where id='".$id."'";
	
	if($conn->query($insert) && $conn->query($insert1)){

		$_SESSION['msg']="Saved successfully";
			header('location:edit.php?id='.$id);
	}else{
$_SESSION['msg']="";
		echo "Ooppss cannot add data" . $conn->error;
		header('location:home.php');
	}

	
	$conn->close();
}
?>

<!-- <link rel="stylesheet" type="text/css" href="mycss.css"> -->

<body>
	<div id="body">
		<div id="session_msg">
			<?php echo $_SESSION['msg'];?>
			
		</div>
		<?php $viewname = "SELECT * from users where id = '$id'";

		$get_outstanding='SELECT sum(credit - debit) from ledger_data where id='.$id;
		$outstanding=$db->query($get_outstanding);
		
			echo '<br>'.
				 'Overview'.
				 '<br>'.
				 'Name: '.$result=$conn->query($viewname)->fetch_assoc()['name'].
				 '<br>'.
				 'Company Name: '.$details_result['company_name'].
				 '<br>'.
				 'Total Outstanding: '. $outstanding->fetch_assoc()['sum(credit - debit)'] .' Rs'
				 ;
			?>
		<div id="content">
			<button style="background: #3F51B5;" class="button btnPush btnBlueGreen"
				onclick="window.location.href='home.php'">Home</button>
			<div id="myDIV" class="btn-grid">
				<button onclick="overview()" class="button btnPush btnBlueGreen btnArrow active">Overview</button>
				<button onclick="billing_address()" class="button btnPush btnBlueGreen btnArrow">Billing Address</button>
				<button onclick="shipping_address()" class="button btnPush btnBlueGreen btnArrow">Shipping Address</button>
				<button onclick="contact()" class="button btnPush btnBlueGreen btnArrow">Contact / Ref</button>
				<button onclick="gst()" class="button btnPush btnBlueGreen btnArrow">GST / Bank</button>
				<button onclick="ledger()" class="button btnPush btnBlueGreen btnArrow">Ledger</button>
				<button onclick="products()" class="button btnPush btnBlueGreen btnArrow">Items / Goods</button>
			</div>

			<form action="" method="POST">

				<!-- overview starts -->
				<div id="overview" class="tabcontent">
					<table class="customers">
						<tr>
							<td>Company Name</td>
							<td><input type="text" name="company_name"
									value="<?php echo $details_result['company_name'];?>"
									placeholder="Type company name here.."></td>
						</tr>
						<tr>
							<td>Name</td>
							<td><input type="text" name="name" value="<?php echo $row['name'];?>"
									placeholder="Type name here.."></td>
						</tr>
						<tr>
							<td>Mobile</td>
							<td><input type="text" name="fname" value="<?php echo $row['username'];?>"
									placeholder="Type Firstname here"></td>
						</tr>
						<tr>
							<td>Role</td>
							<td><input type="text" name="lname" value="<?php echo $row['user_type'];?>"
									placeholder="Type Last Name here.."></td>
						</tr>
						<tr>
							<td>Password</td>
							<td><input type="text" name="password_1" value="<?php echo md5($row['password']);?>" placeholder="Type password here.."></td>
						</tr>
					</table>
				</div>
				<!-- overview ends -->

				<!-- billing starts -->
				<div id="billing_address" class="tabcontent">
					<table class="customers">
						<tr>
							<td>Address</td>
							<td><input type="text" name="billing_address"
									value="<?php echo $details_result['billing_address'];?>"
									placeholder="Type address here.."></td>
						</tr>
						<tr>
							<td>Place</td>
							<td><input type="text" name="billing_place"
									value="<?php echo $details_result['billing_place'];?>"
									placeholder="Type place here.."></td>
						</tr>
						<tr>
							<td>pincode</td>
							<td><input type="text" name="billing_pincode"
									value="<?php echo $details_result['billing_pincode'];?>"
									placeholder="Type pincode here.."></td>
						</tr>
						<tr>
							<td>state</td>
							<td><input type="text" name="billing_state"
									value="<?php echo $details_result['billing_state'];?>"
									placeholder="Type state here.."></td>
						</tr>
						<tr>
							<td>country</td>
							<td><input type="text" name="billing_country"
									value="<?php echo $details_result['billing_country'];?>"
									placeholder="Type country here.."></td>
						</tr>
						<tr>
							<td>credit days</td>
							<td><input type="text" name="billing_credit_days"
									value="<?php echo $details_result['billing_credit_days'];?>"
									placeholder="Type credit days here.."></td>
						</tr>
						<tr>
							<td>credit limit</td>
							<td><input type="text" name="billing_credit_limit"
									value="<?php echo $details_result['billing_credit_limit'];?>"
									placeholder="Type credit limit here.."></td>
						</tr>
						<tr>
							<td>kilometer</td>
							<td><input type="text" name="billing_kilometer"
									value="<?php echo $details_result['billing_kilometer'];?>"
									placeholder="Type kilometer here.."></td>
						</tr>
					</table>
				</div>
				<!-- billing ends -->

				<div id="shipping_address" class="tabcontent">
					<table class="customers">
						<tr>
							<td>Address</td>
							<td><input type="text" name="address" value="<?php echo $details_result['address'];?>"
									placeholder="Type address here.."></td>
						</tr>
						<tr>
							<td>Place</td>
							<td><input type="text" name="place" value="<?php echo $details_result['place'];?>"
									placeholder="Type place here.."></td>
						</tr>
						<tr>
							<td>pincode</td>
							<td><input type="text" name="pincode" value="<?php echo $details_result['pincode'];?>"
									placeholder="Type pincode here.."></td>
						</tr>
						<tr>
							<td>state</td>
							<td><input type="text" name="state" value="<?php echo $details_result['state'];?>"
									placeholder="Type state here.."></td>
						</tr>
						<tr>
							<td>country</td>
							<td><input type="text" name="country" value="<?php echo $details_result['country'];?>"
									placeholder="Type country here.."></td>
						</tr>
						<tr>
							<td>credit days</td>
							<td><input type="text" name="credit_days"
									value="<?php echo $details_result['credit_days'];?>"
									placeholder="Type credit days here.."></td>
						</tr>
						<tr>
							<td>credit limit</td>
							<td><input type="text" name="credit_limit"
									value="<?php echo $details_result['credit_limit'];?>"
									placeholder="Type credit limit here.."></td>
						</tr>
						<tr>
							<td>kilometer</td>
							<td><input type="text" name="kilometer" value="<?php echo $details_result['kilometer'];?>"
									placeholder="Type kilometer here.."></td>
						</tr>
					</table>
				</div>

				<div id="contact">
					<table class="customers">
						<tr>
							<td>phone</td>
							<td><input type="text" name="phone" value="<?php echo $details_result['phone'];?>"
									placeholder="Type phone here.."></td>
						</tr>
						<tr>
							<td>mobile</td>
							<td><input type="text" name="mobile" value="<?php echo $details_result['mobile'];?>"
									placeholder="Type mobile here.."></td>
						</tr>
						<tr>
							<td>email</td>
							<td><input type="text" name="email" value="<?php echo $details_result['email'];?>"
									placeholder="Type email here.."></td>
						</tr>
						<tr>
							<td>website</td>
							<td><input type="text" name="website" value="<?php echo $details_result['website'];?>"
									placeholder="Type website here.."></td>
						</tr>
						<tr>
							<td>reference</td>
							<td><input type="text" name="reference" value="<?php echo $details_result['reference'];?>"
									placeholder="Type reference here.."></td>
						</tr>
						<tr>
							<td>owner</td>
							<td><input type="text" name="owner" value="<?php echo $details_result['owner'];?>"
									placeholder="Type owner here.."></td>
						</tr>
					</table>
				</div>

				<div id="gst">
					<table class="customers">
						<tr>
							<td>GST place</td>
							<td><input type="text" name="gst_place" value="<?php echo $details_result['gst_place'];?>"
									placeholder="Type gst_place here.."></td>
						</tr>
						<tr>
							<td>state code</td>
							<td><input type="text" name="state_code" value="<?php echo $details_result['state_code'];?>"
									placeholder="Type state_code here.."></td>
						</tr>
						<tr>
							<td>GST No</td>
							<td><input type="text" name="gst_no" value="<?php echo $details_result['gst_no'];?>"
									placeholder="Type gst_no here.."></td>
						</tr>
						<tr>
							<td>Permanent A/c no.</td>
							<td><input type="text" name="account_no" value="<?php echo $details_result['account_no'];?>"
									placeholder="Type account_no here.."></td>
						</tr>
						<tr>
							<td>Bank Name</td>
							<td><input type="text" name="bank_name" value="<?php echo $details_result['bank_name'];?>"
									placeholder="Type bank_name here.."></td>
						</tr>
						<tr>
							<td>Bank Account</td>
							<td><input type="text" name="account_type"
									value="<?php echo $details_result['account_type'];?>"
									placeholder="Type account_type here.."></td>
						</tr>
						<tr>
							<td>IFSC Code</td>
							<td><input type="text" name="ifsc" value="<?php echo $details_result['ifsc'];?>"
									placeholder="Type ifsc here.."></td>
						</tr>
						<tr>
							<td>Branch</td>
							<td><input type="text" name="branch" value="<?php echo $details_result['branch'];?>"
									placeholder="Type branch here.."></td>
						</tr>
					</table>
				</div>

				<div id="products">
					<button id="add">Add</button>	
					<table class="customers">
						<thead>
						<tr>
							<td>Sr. No.</td>
							<td>Description Of Goods</td>
							<td>Grade</td>
							<td>Quality</td>
							<td>Rate(mm)</td>
							<td>Rate(kg)</td>
							<td>Rate(SQ.FT)</td>
							<td>Rate(mtr)</td>
							<td>Rate(pcs)</td>
							<td>Gst Rate</td>
							<td>HSN</td>
						</tr>
						</thead>
						<tbody>
						<tr>
							<td>1</td>
							<td><input type="text" name="description_of_goods"
									value="<?php echo $details_result['description_of_goods'];?>"
									placeholder="Type description_of_goods here"></td>
							<td><input type="text" name="grade" value="<?php echo $details_result['grade'];?>"
									placeholder="Type grade here.."></td>
							<td><input type="text" name="quality" value="<?php echo $details_result['quality'];?>"
									placeholder="Type quality here.."></td>
							<td><input type="text" name="rate_per_mm"
									value="<?php echo $details_result['rate_per_mm'];?>"
									placeholder="Type rate_per_mm here"></td>
							<td><input type="text" name="rate_per_kg"
									value="<?php echo $details_result['rate_per_kg'];?>"
									placeholder="Type rate_per_kg here.."></td>
							<td><input type="text" name="rate_per_sqft"
									value="<?php echo $details_result['rate_per_sqft'];?>"
									placeholder="Type rate_per_sqft here.."></td>
							<td><input type="text" name="rate_per_mtr"
									value="<?php echo $details_result['rate_per_mtr'];?>"
									placeholder="Type rate_per_mtr here"></td>
							<td><input type="text" name="rate_per_pcs"
									value="<?php echo $details_result['rate_per_pcs'];?>"
									placeholder="Type rate_per_pcs here.."></td>
							<td><input type="text" name="gst_rate" value="<?php echo $details_result['gst_rate'];?>"
									placeholder="Type gst_rate here.."></td>
							<td><input type="text" name="hsn" value="<?php echo $details_result['hsn'];?>"
									placeholder="Type hsn here.."></td>
						</tr>
						</tbody>
					</table>
				</div>
				<button id="toggleEdit" style="background: #4CAF50;" class="button btnPush btnBlueGreen" type="button">Edit</button>
				<button style="background: #4CAF50;" class="button btnPush btnBlueGreen" type="submit"
					name="update" readonly>Save</button>
			</form>

			<div id="ledger">
				<!--don't keep two forms inside each other-->
				<div id="importFrm">
					<form action="importdata.php?id=<?php echo $id;?>" method="post" enctype="multipart/form-data">
						<table class="customers">
							<tbody>
								<tr>
								<td class="chooseFileTd">
									<input class="chooseFileInput" type="file" name="file" />
									<input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
								</td>
								
							</tr>
							</tbody>
							
						</table>
					</form>

				<?php echo $_GET['status'] ;
				
				$get_outstanding='SELECT sum(credit - debit) from ledger_data where id='.$id;
				$outstanding=$db->query($get_outstanding);
				echo 'Outstanding Balance: ' . $outstanding->fetch_assoc()['sum(credit - debit)'] .' Rs';

				$get_details='select * from ledger_data where id='.$id;
				$result=$db->query($get_details);

				echo '<table id="customers" class="unfiltered">
						<tr>
							<th>date</th>
							<th>particulars</th>
							<th>remark</th>
							<th>voucher_type</th>
							<th>voucher_no</th>
							<th>debit</th>
							<th>credit</th>
						</tr>
					'; 
				while($row=$result->fetch_assoc()){
				echo 
				'
				<tr>
					<td>'.$row["date"].'</td>
					<td>'.$row["particulars"].'</td>
					<td>'.$row["remark"].'</td>
					<td>'.$row["voucher_type"].'</td>
					<td>'.$row["voucher_no"].'</td>
					<td>'.$row["debit"].'</td>
					<td>'.$row["credit"].'</td>
				</tr>
				';
				}
				echo '</table>';
					?>
				</div>
			</div>

		</div>
	</div>


<script type="text/javascript">
$("input:text").prop("readonly", true);
(function($) {
    $.fn.toggleReadonly = function() {
        return this.each(function() {
            var $this = $(this);
            if ($this.attr('readonly')) $this.removeAttr('readonly');
            else $this.attr('readonly', 'readonly');
        });
    };
})(jQuery);

$(function() {
    $('#toggleEdit').click(function() {
        $('input:text').toggleReadonly();
        $("[name='update']").attr("readonly", false);
    });
});
</script>
				
	<script>
		overview = () => {
			document.querySelector('#overview').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
		}
		billing_address = () => {
			document.querySelector('#billing_address').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
		shipping_address = () => {
			document.querySelector('#shipping_address').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
		contact = () => {
			document.querySelector('#contact').style.display = "block";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
		gst = () => {
			document.querySelector('#gst').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
		ledger = () => {
			document.querySelector('#ledger').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
			document.querySelector('#products').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
		products = () => {
			document.querySelector('#products').style.display = "block";
			document.querySelector('#contact').style.display = "none";
			document.querySelector('#shipping_address').style.display = "none";
			document.querySelector('#gst').style.display = "none";
			document.querySelector('#billing_address').style.display = "none";
			document.querySelector('#ledger').style.display = "none";
			document.querySelector('#overview').style.display = "none";
		}
	</script>

	<!-- update starts -->
	<script>
		// $(document).ready(() => {
		// 	const msg = document.querySelector('.msg');
		// 	setTimeout(() => {
		// 		msg.style.display = "none"
		// 	}, 3000);
		// });
	</script>
	<!-- update starts -->

<script>
var sr_no=2;
    document.querySelector('#add').onclick = (e) => {
    	e.preventDefault();
        document.querySelector('#products table tbody').lastElementChild.insertAdjacentHTML("afterend",'<td>'+sr_no+'</td><td><input type="text" name="description_of_goods"value=""placeholder="Type description_of_goods here"></td><td><input type="text" name="grade" value=""placeholder="Type grade here.."></td><td><input type="text" name="quality" value=""placeholder="Type quality here.."></td><td><input type="text" name="rate_per_mm"value=""placeholder="Type rate_per_mm here"></td><td><input type="text" name="rate_per_kg"value=""placeholder="Type rate_per_kg here.."></td><td><input type="text" name="rate_per_sqft"value=""placeholder="Type rate_per_sqft here.."></td><td><input type="text" name="rate_per_mtr"value=""placeholder="Type rate_per_mtr here"></td><td><input type="text" name="rate_per_pcs"value=""placeholder="Type rate_per_pcs here.."></td><td><input type="text" name="gst_rate" value=""placeholder="Type gst_rate here.."></td><td><input type="text" name="hsn" value=""placeholder="Type hsn here.."></td>');
        sr_no++; 
    };
</script>

<script>
// Add active class to the current button (highlight it)
var header = document.getElementById("myDIV");
var btns = header.getElementsByClassName("btnArrow");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  var current = document.getElementsByClassName("active");
  current[0].className = current[0].className.replace(" active", "");
  this.className += " active";
  });
}
</script>

<script>
const mm=document.querySelector('[placeholder="Type rate_per_mm here"]');
const kg=document.querySelector('[placeholder="Type rate_per_kg here.."]');
const sqft=document.querySelector('[placeholder="Type rate_per_sqft here.."]');
const mtr=document.querySelector('[placeholder="Type rate_per_mtr here"]');
const pcs=document.querySelector('[placeholder="Type rate_per_mtr here"]');
mm.onchange=()=>{	
   kg.readonly=true;
   sqft.readonly=true;
   mtr.readonly=true;
   pcs.readonly=true;}
kg.onchange=()=>{
   mm.readonly=true;
   sqft.readonly=true;
   mtr.readonly=true;
   pcs.readonly=true;}
sqft.onchange=()=>{
   mm.readonly=true;
   mtr.readonly=true;
	kg.readonly=true;
   pcs.readonly=true;}
mtr.onchange=()=>{
   mm.readonly=true;
   sqft.readonly=true;
   kg.readonly=true;
   pcs.readonly=true;}
pcs.onchange=()=>{
	mm.readonly=true;
	sqft.readonly=true;
	kg.readonly=true;
	mtr.readonly=true;}
</script>

</body>