<?php
include '../functions.php';

if (!isStaff()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../login.php');
}
?>

<!-- add starts -->
<?php
include 'conn.php';
if (isset($_POST['add'])) {

    $name = $_POST['name'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password_1 = $_POST['password_1'];
    $password_2 = $_POST['password_2'];
    $password = md5($password_1); //encrypt the password before saving in the database

    $insert = "insert into users (name,username,user_type,email,password) values ('$name','$fname','$lname','$email','$password')";

    // adds columns starts
    $insert_details = "insert into vendor_details (mobile) values ('$fname')";
    $conn->query($insert_details);
    // ends

    if ($conn->query($insert) == true) {

        echo "Sucessfully add data";
        header('location:home.php');
    } else {

        echo "Ooppss cannot add data" . $conn->connect_error;
        header('location:home.php');
    }
    $insert->close();
}
?>
<!-- add ends -->

<!DOCTYPE html>
<html>
<head>
	<title>Staff Home</title>
	<link rel="stylesheet" type="text/css" href="../sass/oldstyle.css">
	<style>
	.header {
		background: #003366;
	}
	button[name=register_btn] {
		background: #003366;
	}
	.dashboard{
		display: flex;
	}
	</style>
</head>
<body>
	<div class="header">
		<h2>Staff - Home Page</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])): ?>
			<div class="error success" >
				<h3>
					<?php
echo $_SESSION['success'];
unset($_SESSION['success']);
?>
				</h3>
			</div>
		<?php endif?>

		<!-- logged in user information -->
		<div class="profile_info">
			<img src="../images/admin_profile.png"  >

			<div>
				<?php if (isset($_SESSION['user'])): ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i>
						<br>
						<a href="home.php?logout='1'" style="color: red;">logout</a>
						<!-- &nbsp; <a href="create_user.php"> + add vendor</a> -->
					</small>

				<?php endif?>
			</div>
			<!-- <a href="maintenance.php" style="font-size: 15px;">Delete Vendor</a> -->
			</div>
<!-- starts -->
<?php
include 'conn.php';
// include 'session.php';
?>
<link rel="stylesheet" type="text/css" href="mycss.css">
<div id="body">
	<div id="content" class="dashboard">
		<form action="home.php" method="POST">
		<table align="center">
				<tr>
					<h3>Create New Accounts</h3><br>
					<td>Name: <input type="text" name="name" value="" placeholder="Type name here" required></td>
				</tr>
				<tr>
					<td>Mobile No: <input type="text" name="fname" value="" placeholder="Type mobile here" required></td>
				</tr>
				<tr>
					<td>
						User Type:
						<select name="lname">
							<option value="user">Vendor</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Email: <input type="text" name="email" value="" placeholder="Type username here" required></td>
				</tr>
				<tr>
					<td>Password: <input type="text" name="password_1" placeholder="Type user type here.." required></td>
				</tr>
				<tr>
					<td>Confirm Password: <input type="text" name="password_2" placeholder="Type user type here.." required></td>
				</tr>
				<tr>
					<td><input type="submit" name="add" value="Add"></td>
				</tr>
		</table>
	</form>
		<br>
		<table align="center" border="1" cellspacing="0" width="500">
			<tr>
			<th>Name</th>
			<th>Mobile No</th>
			<th>Role</th>
			<th>Action</th>
			<th>Status</th>
			</tr>
			<?php
$sql = "SELECT * FROM users join vendor_details on users.id=vendor_details.id where user_type='user'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        ?>
				<tr>
					<td align="center"><?php echo $row['name']; ?></td>
					<td align="center"><?php echo $row['username']; ?></td>
					<td align="center"><?php echo $row['user_type']; ?></td>
					<td align="center"><a href="edit.php?id=<?php echo $row['id']; ?>">Edit
					</a>/<a href="delete.php?id=<?php echo md5($row['id']); ?>">Delete</a></td>
					<td onclick="statuschange();"><?php
$vsql = "select * from vendor_details where mobile=" . $row['username'];
        $status = $conn->query($vsql)->fetch_assoc();
        switch ($status['status']) {case 0:
                echo 'disabled';
                break;
            case 1:
                echo 'enabled';
                break;
            default:
                echo 'status not set';}
        ?></td>
				</tr>
				<?php
}
} else {
    echo "<center><p> No Records</p></center>";
}

$conn->close();
?>
		</table>
	</div>
</div>
<!-- ends -->
	</div>

<script>
function statuschange(){
	document.onclick=(e)=>{
		var currentStat=e.target.parentNode.children[4].innerHTML;
		var mobile=e.target.parentNode.children[1].innerHTML;
		var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            e.target.parentNode.children[4].innerHTML = this.responseText;
        }
    };
    xmlhttp.open("GET", "chkstatus.php?q=" + currentStat+"&mobile="+mobile, true);
    xmlhttp.send();


		}
}

</script>

</body>
</html>