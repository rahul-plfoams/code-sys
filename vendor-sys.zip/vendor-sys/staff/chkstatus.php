<?php
$db = new mysqli('localhost', 'root', 'root', 'vendor_db');
$q = $_GET["q"];
$mobile=$_GET["mobile"];
if ($q === "enabled") {
$disable="update vendor_details set status=0 where mobile=".$mobile;
$db->query($disable);
$result="disabled";
}
elseif($q === "disabled") {
$enable="update vendor_details set status=1 where mobile=".$mobile;
$db->query($enable);
$result="enabled";
}

echo $result;
?>