<?php
define("TITLE", "vendor");
require_once "./admin/nav.php";
$sql = "SELECT * FROM users INNER JOIN vendor_details USING(id) WHERE id=" . $_SESSION['user']['id'];
$vendororders = "SELECT * FROM orders WHERE vendor_id=" . $_SESSION['user']['id'];
$ledger = "SELECT * FROM ledger_data WHERE id=" . $_SESSION['user']['id'];
$result = $db->query($sql)->fetch_assoc();
$result1 = $db->query($ledger);
$orderhistory = $db->query($vendororders);
?>
<style>
	#listProducts thead:first-child td {
		max-width: 50px;
	}

	.iwidth {
		min-width: 130px !important;
	}

	#listProducts textarea {
		min-width: 130px;
	}
</style>
<div class="container-fluid mt--7">
	<div class="card">
		<div class="card-header">
			<div class="d-flex">
				Overview
			</div>
		</div>
		<div class="card-body">
			<p class="card-text">
				Name: <?=$result['mobile']?><br>
				Company Name:<?=$result['company_name']?><br>
				Total Outstanding:<br>
				<!-- Nav tabs -->
				<ul class="nav nav-tabs nav-justified" role="tablist">
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#billing">Billing Address</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#shipping">Shipping Address</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#contact">Contact/Ref</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#gst">GST/Bank</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#ledger">View Ledger</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#items">Items/Goods</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#placeorder">Place Orders</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#orders">Orders</a>
					</li>

				</ul>
				<div class="tab-content">
					<div id="billing" class="container tab-pane active">
						<table class="table table-bordered">
							<tr>
								<td>Address</td>
								<td><?=$result['billing_address']?></td>
							</tr>
							<tr>
								<td>Place</td>
								<td><?=$result['billing_city']?></td>
							</tr>
							<tr>
								<td>Pincode</td>
								<td><?=$result['billing_pincode']?></td>
							</tr>
							<tr>
								<td>State</td>
								<td><?=$result['billing_state']?></td>
							</tr>
							<tr>
								<td>Country</td>
								<td><?=$result['billing_country']?></td>
							</tr>
							<tr>
								<td>Credit Days</td>
								<td><?=$result['billing_credit_days']?></td>
							</tr>
							<tr>
								<td>Credit Limit</td>
								<td><?=$result['billing_credit_limit']?></td>
							</tr>
							<tr>
								<td>Kilometer</td>
								<td><?=$result['billing_kilometer']?></td>
							</tr>
						</table>
					</div>
					<div id="items" class="container tab-pane fade">
					<table class="table table-bordered">
						<thead>
							<tr>
								<td>Sr</td>
								<td>Name</td>
								<td>Grade</td>
								<td>Quality</td>
								<td>Unit</td>
								<td>Remark</td>
							</tr>
						</thead>
						<tbody>
						<?php
$sql_res = "SELECT * FROM vendor_pref JOIN products using(product_id) where vendor_id=" . $_SESSION['user']['id'];
$tabres = $db->query($sql_res);
$tsr = 1;
while ($tabrow = $tabres->fetch_assoc()):
?>
							<tr>
								<td class="align-middle"><?=$tsr;?></td>
								<td class="align-middle"><?=$tabrow['product_name']?></td>
								<td class="align-middle"><?=$tabrow['grade']?></td>
								<td class="align-middle"><?=$tabrow['quality']?></td>
								<td class="align-middle"><?=$tabrow['unit']?></td>
								<td class="align-middle p-0"><?=$tabrow['product_remark']?></td>
								</tr>
								<?php $tsr++;
endwhile;?>
						</tbody>
					</table>
					</div>
					<div id="shipping" class="container tab-pane fade">
						<table class="table table-bordered">
							<tr>
								<td>Address</td>
								<td><?=$result['address']?></td>
							</tr>
							<tr>
								<td>Place</td>
								<td><?=$result['city']?></td>
							</tr>
							<tr>
								<td>Pincode</td>
								<td><?=$result['pincode']?></td>
							</tr>
							<tr>
								<td>State</td>
								<td><?=$result['state']?></td>
							</tr>
							<tr>
								<td>Country</td>
								<td><?=$result['country']?></td>
							</tr>
							<tr>
								<td>Credit Days</td>
								<td><?=$result['credit_days']?></td>
							</tr>
							<tr>
								<td>Credit Limit</td>
								<td><?=$result['credit_limit']?></td>
							</tr>
							<tr>
								<td>Kilometer</td>
								<td><?=$result['kilometer']?></td>
							</tr>
						</table>
					</div>
					<div id="contact" class="container tab-pane fade">
						<table class="table table-bordered">
							<tr>
								<td>Phone</td>
								<td><?=$result['phone']?></td>
							</tr>
							<tr>
								<td>Mobile</td>
								<td><?=$result['mobile']?></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><?=$result['email']?></td>
							</tr>
							<tr>
								<td>Website</td>
								<td><?=$result['website']?></td>
							</tr>
							<tr>
								<td>Reference</td>
								<td><?=$result['reference']?></td>
							</tr>
							<tr>
								<td>Owner</td>
								<td><?=$result['owner']?></td>
							</tr>
						</table>
					</div>
					<div id="gst" class="container tab-pane fade">
						<table class="table table-bordered">
							<tr>
								<td>GST Place</td>
								<td><?=$result['gst_place']?></td>
							</tr>
							<tr>
								<td>State Code</td>
								<td><?=$result['state_code']?></td>
							</tr>
							<tr>
								<td>GST No</td>
								<td><?=$result['gst_no']?></td>
							</tr>
							<tr>
								<td>Permanent A/c no.</td>
								<td><?=$result['account_no']?></td>
							</tr>
							<tr>
								<td>Bank Name</td>
								<td><?=$result['bank_name']?></td>
							</tr>
							<tr>
								<td>Bank Account</td>
								<td><?=$result['account_type']?></td>
							</tr>
							<tr>
								<td>IFSC Code</td>
								<td><?=$result['ifsc']?></td>
							</tr>
							<tr>
								<td>Branch</td>
								<td><?=$result['branch']?></td>
							</tr>
						</table>
					</div>
					<div id="ledger" class="container tab-pane fade">


						<form id="calendar" method="post" class="form row text-center mx-auto">
							<input class="form-control col-lg-3 m-2" type="date" name="fromDate">
							<input class="form-control col-lg-3 m-2" type="date" name="toDate">
							<input class="btn btn-success col-lg-3 m-2" type="submit">
						</form>
						<div class="row">
						<div class="col-lg-4 mx-auto">
						<form>
							<select class="form-control" name="users" onchange="showUser(this.value)">
								<option value="1">Select duration:</option>
								<option value="1">admin</option>
								<option value='<?=$_SESSION['user']['id']?>'>last 3 months</option>
							</select>
						</form>
						</div>
						</div>
						<table class="filtered table table-bordered">
							<tr>
								<th>Date</th>
								<th>Particulars</th>
								<th>Remark</th>
								<th>Voucher Type</th>
								<th>Voucher No</th>
								<th>Debit</th>
								<th>Credit</th>
							</tr>
							<tbody id="txtHint">
								<?php while ($row = $result1->fetch_assoc()): ?>
								<tr>
									<td><?=$row["date"]?></td>
									<td><?=$row["particulars"]?></td>
									<td><?=$row["remark"]?></td>
									<td><?=$row["voucher_type"]?></td>
									<td><?=$row["voucher_no"]?></td>
									<td><?=$row["debit"]?></td>
									<td><?=$row["credit"]?></td>
								</tr>
								<?php endwhile;?>
							</tbody>
						</table>
					</div>
					<div id="orders" class="container tab-pane fade">
						<table class="table table-bordered">
							<thead>
								<tr>
									<td>Order No.</td>
									<td>Order Date</td>
									<td class="w-25">Actions</td>
								</tr>
							</thead>
							<tbody>
								<?php
while ($row = $orderhistory->fetch_assoc()):
    $order = unserialize($row['order_details']);?>
															<tr>
																<td class="align-middle"><?=$row['order_id']?></td>
																<td class="align-middle"><?=$row['order_generated']?></td>
																<td class="align-middle"><a class="btn btn-dark"
																		href="orderEdit.php?orderid=<?=$row['order_id']?>">Edit</a><a
																		class="btn btn-danger" href="">Delete</a></td>
															</tr>
															<?php endwhile;?>
							</tbody>
						</table>
					</div>
					<div id="placeorder" class="container tab-pane fade row p-0 m-0">
						<div class="col-lg-12">
							<form>
								<div class="form-group row mt-3">
									<div class="col-lg-4 mx-auto">
										<input type="text" size="30" class="searching form-control"
											onkeyup="showResult(this.value)" placeholder="Search Product here">
									</div>
								</div>
								<div class="form-group row">
									<div class="col">
										<div id="livesearch">
										</div>
									</div>
								</div>
							</form>
						</div>
						<form action="order.php" method="post">
							<table id="listProducts" class="table table-bordered table-hover table-sm">
								<thead>
									<tr>
										<td class="justify-content-center p-2">Sr. No</td>
										<td class="iwidth">SKU/Code</td>
										<td>Name</td>
										<td>Grade</td>
										<td>Quality</td>
										<td>Unit</td>
										<td>GST</td>
										<td class="iwidth">Length</td>
										<td class="iwidth">Width</td>
										<td class="iwidth">Thickness</td>
										<td class="iwidth">Quantity</td>
										<td>remark</td>
									</tr>
								</thead>
								<tbody id="ordertable">
								</tbody>
							</table>
							<input class="btn btn-success " type="submit" value="Place Order">
						</form>
					</div>
				</div>
		</div>
	</div>
</div>
<?php require_once "footer.php"?>
<script src="./js/index.js"></script>