<?php
session_start();
$vendor_id = $_SESSION['user']['id'];
// $product_id = $_GET['id'];
$p_in = $_GET['p_in'];
$sr = $_GET['sr'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "SELECT * FROM  vendor_pref JOIN products ON vendor_pref.product_id=products.product_id where p_in=$p_in";
// echo $sql;
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()):
?>
<tr>
<td class="align-middle"><?=$sr + 1?></td>
<td class="align-middle"><input class="form-control" width="15" type="text" name="vendor_code[]" placeholder="code">
</td>
<td class="align-middle"><?=$row['product_name']?>
<input type="hidden" name="product_id[]" value='<?=$row['product_id']?>'>
</td>
<td class="align-middle"><?=$row['grade']?>
</td>

<td class="align-middle"><?=$row['quality']?>
</td>
<td class="align-middle"><?=$row['unit']?>
</td>
<td class="align-middle"><?=$row['gst_rate']?>
</td>
<td class="align-middle"><input class="form-control"  type="number" name="length[]" placeholder="enter length">
</td>
<td class="align-middle"><input class="form-control"  type="number" name="width[]" placeholder="enter width">
</td>
<td class="align-middle"><input class="form-control"  type="number" name="thickness[]" placeholder="enter thickness">
</td>
<td class="align-middle"> <input class="form-control"  type="number" name="quantity[]" placeholder="enter quantity"> </td>
<td class="align-middle p-0"><textarea class="form-control" type="text" name="remark[]" placeholder="enter remarks if any" data="<?=$vendor_id?>"></textarea></td>

</tr>
<?php endwhile;?>