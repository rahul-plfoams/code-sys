<?php
session_start();
$query = strtolower($_GET['q']);
$vendor_id = $_SESSION['user']['id'];
$conn = new mysqli("localhost", "root", "", "vendor_db");
$details = "SELECT * FROM vendor_pref JOIN products using(product_id) WHERE vendor_id=$vendor_id";
$result = $conn->query($details);
if (strlen($query) > 0) {
    while ($row = $result->fetch_assoc()) {
        if (preg_match("/$query/", strtolower($row['product_name']))) {?>
            <div class='row text-center border border-dark' onclick='add(this)' data-val='<?=$row['p_in']?>'>
                <div class='col font-weight-bold p-1 text-uppercase'><?=$row['product_name']?></div>
                <div class='col text-white bg-gradient-blue p-1'><?=$row['grade']?></div>
                <div class='col text-white bg-gradient-gray-dark p-1'><?=$row['quality']?></div>
            </div>
        <?php

        }
    }
}
?>
