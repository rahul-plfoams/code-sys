<?php

$product_id = $_GET['id'];
$sr = $_GET['sr'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products where product_id='$product_id'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()):
?>
<tr>
<td class="align-middle"><?=$sr + 1?></td>
<td class="align-middle"><input class="form-control" type="text" name="products[]" value='<?=$row['product_name']?>' readonly>
<input type="hidden" name="product_id[]" value='<?=$row['product_id']?>'>
</td>
<td class="align-middle"><?=$row['grade']?></td>
<td class="align-middle"><?=$row['quality']?></td>
<td class="align-middle"><input class="form-control" type="number" name="rate[]" value='<?=$row['sale_rate']?>'></td>
<td class="align-middle"><?=$row['unit']?></td>
<td class="align-middle"><?=$row['gst_rate']?></td>
<td class="align-middle p-0"><textarea class="form-control" type="text" name="remark[]" value='<?=$row['remark']?>'><?=$row['remark']?></textarea></td>

</tr>
<?php endwhile;?>