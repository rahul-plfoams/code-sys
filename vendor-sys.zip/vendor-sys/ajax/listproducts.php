<?php
$query = strtolower($_GET['q']);
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products";
$result = $conn->query($sql);
if (strlen($query) > 0) {
    while ($row = $result->fetch_assoc()) {

        if (preg_match("/$query/", strtolower($row['product_name']))) {
            echo "<div class='row text-center border border-dark' onclick='add(this)' data-val='" . $row['product_id'] . "'><div class='col font-weight-bold p-1 text-uppercase'>" . $row['product_name'] . "</div><div class='col text-white bg-gradient-blue p-1'>" . $row['grade'] . "</div><div class='col text-white bg-gradient-gray-dark p-1'>" . $row['quality'] . "</div></div>";
        }

    }
}
