<?php
date_default_timezone_set('Asia/Kolkata');
$sr = $_GET['sr'];
$rate = $_GET['rate'];
$remark = $_GET['remark'];
$p_in = $_GET['p_in'];
$date = date('Y-m-d H:i:s');
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$updatesql = "UPDATE vendor_pref SET product_rate=$rate,product_remark='$remark',modified_date='$date' WHERE p_in=$p_in";
$conn->query($updatesql);
$sql = "SELECT * FROM vendor_pref JOIN products ON vendor_pref.product_id=products.product_id WHERE p_in=$p_in";
$result = $conn->query($sql)->fetch_assoc();
?>
<tr>
	<td><?=$sr;?></td>
	<td><?=$result['product_name']?></td>
	<td><?=$result['grade']?></td>
	<td><?=$result['quality']?></td>
	<td><?=$result['product_rate']?></td>
	<td><?=$result['unit']?></td>
	<td><?=$result['gst_rate']?></td>
	<td><?=$result['product_remark']?>
		<span style="color:grey;"> (<?php
if ($result['modified_date'] === null) {
    echo $result['added_date'];
} else {
    echo $result['modified_date'];
}
?>)</span>
	</td>
	<td>
		<a class="btn btn-info" onclick="editVendorProduct(this)" href="#" data-p_in="<?=$result['p_in']?>">Edit</a>
		<a class="btn btn-danger" href="delProduct.php?id=<?=$result['vendor_id']?>&pid=<?=$result['p_in']?>">delete</a>
	</td>

</tr>