<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>

<?php
$q = intval($_GET['q']);

$con = mysqli_connect('localhost', 'root', '', 'vendor_db');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con, "ajax_demo");
// $sql="SELECT * FROM ledger_data WHERE id = '".$q."'";
$sql = "SELECT * FROM ledger_data where  `date` >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH) and id = $q";
// select * from dt_table where  `date` >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['date'] . "</td>";
    echo "<td>" . $row['particulars'] . "</td>";
    echo "<td>" . $row['remark'] . "</td>";
    echo "<td>" . $row['voucher_type'] . "</td>";
    echo "<td>" . $row['voucher_no'] . "</td>";
    echo "<td>" . $row['debit'] . "</td>";
    echo "<td>" . $row['credit'] . "</td>";
    echo "</tr>";
}
mysqli_close($con);
?>