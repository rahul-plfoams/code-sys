<?php
$vendor_id = $_GET['id'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products";
$result = $conn->query($sql);?>
<select>
<?
while ($row = $result->fetch_assoc()):
?>
<option value="<?=$row['id']?>"><?=$row['product_name']?></option>
<?php endwhile;?>
</select>
<button onclick="getProduct()">Add</button>
<a href="home.php" type="button">home</a>

<form action="storePref.php?id=<?=$vendor_id?>" method="post">
<table>
    <thead>
        <tr>
            <td>Sr. No</td>
            <td>Name</td>
            <td>Grade</td>
            <td>Quality</td>
            <td>Rate</td>
            <td>Unit</td>
            <td>GST</td>
            <td>remark</td>
        </tr>
    </thead>
    <tbody id="showProduct">
    </tbody>
</table>
<button type="submit">Save</button>
</form>
<table>
    <thead>
        <tr>
            <td>Sr. No</td>
            <td>Name</td>
            <td>Grade</td>
            <td>Quality</td>
            <td>Rate</td>
            <td>Unit</td>
            <td>GST</td>
            <td>remark</td>
        </tr>
    </thead>
    <tbody>
	<?php
$sql_res = "SELECT * FROM vendor_pref JOIN products ON vendor_pref.product_id=products.product_id where vendor_id=$vendor_id";
$tabres = $conn->query($sql_res);
$tsr = 1;
while ($tabrow = $tabres->fetch_assoc()):

?>
				<tr>
				<td><?=$tsr;?></td>
				<td><?=$tabrow['product_name']?></td>
				<td><?=$tabrow['grade']?></td>
				<td><?=$tabrow['quality']?></td>
				<td><?=$tabrow['product_rate']?></td>
				<td><?=$tabrow['unit']?></td>
				<td><?=$tabrow['gst_rate']?></td>
				<td><?=$tabrow['product_remark']?></td>
				<td><a href="delProduct.php?id=<?=$vendor_id?>&pid=<?=$tabrow['p_in']?>">delete</a></td>

				</tr>
				<?php $tsr++;
endwhile;?>
    </tbody>
</table>


<script>
function getProduct() {
			let sr = document.querySelector('#showProduct').childElementCount;

			const sel = document.querySelector('select');
			str = sel.options[sel.selectedIndex].text;
			xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function () {
				if (this.readyState == 4 && this.status == 200) {

					if (document.querySelector('#showProduct').childElementCount == 0) {
						document.getElementById("showProduct").innerHTML = this.responseText;
					} else {
						document.getElementById("showProduct").lastElementChild.insertAdjacentHTML("afterend", this
							.responseText);
					};
				}
			};
			xmlhttp.open("GET", "ajax/addproductline.php?q=" + str + "&sr=" + sr, true);
			xmlhttp.send();
		}

</script>
