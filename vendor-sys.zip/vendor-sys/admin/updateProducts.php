<?php
include_once '../classes/product.class.php';
$name = $_POST['name'];
$grade = $_POST['grade'];
$quality = $_POST['quality'];
$unit = $_POST['unit'];
$sale_rate = $_POST['sale_rate'];
$gst_rate = $_POST['gst_rate'];
$remark = $_POST['remark'];
$id = $_GET['id'];
$product = new products;
$currtime = date("D, d M Y H:i:s");
$sql = $product->updateProduct($id, $name, $grade, $quality, $unit, $sale_rate, $gst_rate, $remark);
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
echo $conn->query($sql) ? 'successful' : 'failed';
header('location:products.php');
