<?php
$conn=new mysqli("localhost","root","root","vendor_db");
echo $id = $_GET['id'];
if(isset($_POST['importSubmit'])){
    
    // Allowed mime types
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    
    // Validate whether selected file is a CSV file
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)){
        
        // If the file is uploaded
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            // Open uploaded CSV file with read-only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            // Skip the first line
            fgetcsv($csvFile);
            
            // Parse data from CSV file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                // Get row data

                $date   = $line[0];
                $particulars  = $line[1];
                $remark  = $line[2];
                $voucher_type = $line[3];
                $voucher_no = $line[4];
                $debit = $line[5];
                $credit = $line[6];
                
              
                    // Insert member data in the database
                    $conn->query("INSERT INTO ledger_data (id,date, particulars, remark, voucher_type, voucher_no, debit, credit) 
                    VALUES ('".$id."','".$date."', '".$particulars."', '".$remark."', '".$voucher_type."', '".$voucher_no."', '".$debit."', '".$credit."')");
                    
                }
            }
            
            // Close opened CSV file
            fclose($csvFile);
            
            $qstring = '?status=success';
        }else{
            $qstring = '?status=error';
        }
    }else{
        $qstring = '?status=invalid_file';
    }
// Redirect to the listing page
header("Location: edit.php".$qstring);

?>