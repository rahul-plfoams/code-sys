<?php
include 'conn.php';
if (isset($_POST['add'])) {

    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $user_type = $_POST['user_type'];
    $email = $_POST['email'];
    $password_1 = $_POST['password_1'];
    $password_2 = $_POST['password_2'];
    $password = md5($password_1); //encrypt the password before saving in the database
    $date = date("Y-m-d H:i:s");
    $insert = "INSERT INTO users(name,username,user_type,email,password,user_added) values ('$name','$mobile','$user_type','$email','$password','$date')";

// adds columns starts
    $insert_details = "INSERT INTO vendor_details (mobile) values ('$mobile')";
    $conn->query($insert_details);
// ends

    if ($conn->query($insert) == true) {

        echo "Sucessfully add data";
        header('location:home.php');
    } else {

        echo "Ooppss cannot add data" . $conn->connect_error;
        // header('location:home.php');
    }
    // $insert->close();
}
