<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css" />
<form class="section is-centered columns" action="updateProducts.php?id=<?=$_GET['id']?>" method="post">
  <?php
$id = $_GET['id'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products where product_id=$id";

$result = $conn->query($sql);
while ($row = $result->fetch_assoc()): ?>
  <div class="field column">
    <label class="label">name</label>
    <input class="input" type="text" name="name" placeholder="name" value="<?=$row['product_name']?>" />
  </div>
  <div class="field column">
    <label class="label">Grade</label>
    <input class="input" type="text" name="grade" placeholder="Product Grade" value="<?=$row['grade']?>" />
  </div>
  <div class="field column">
    <label class="label">Quality</label>
    <input class="input" type="text" name="quality" placeholder="Product Quality" value="<?=$row['quality']?>" />
  </div>
  <div class="field column">
    <label class="label">Sale Rate</label>
    <input class="input" type="text" name="sale_rate" placeholder="Product Price" value="<?=$row['sale_rate']?>" />
  </div>
  <div class="field column">
    <label class="label">GST Rate</label>
    <input class="input" type="text" name="gst_rate" placeholder="GST Rate" value="<?=$row['gst_rate']?>" />
  </div>
  <div class="field column">
    <label class="label">Remark</label>
    <input class="input" type="text" name="remark" placeholder="Remark/Specification" value="<?=$row['remark']?>" />
  </div>
  <div class="field column">
    <label class="is-centered label">unit</label>
    <div class="select">
      <select name="unit">
        <option>mm</option>
        <option>kg</option>
        <option>Sq.Ft</option>
        <option>Pcs</option>
        <option>Meter</option>
      </select>
    </div>
  </div>
  <div class="field is-grouped column">
    <div class="control">
      <button class="button is-link" value="Save">Save</button>
    </div>
    <div class="control">
      <button class="button is-text">Cancel</button>
    </div>
  </div>
  <?php endwhile;?>
</form>