<?php
date_default_timezone_set('Asia/Kolkata');
include_once '../classes/product.class.php';
$name = $_POST['name'];
$grade = $_POST['grade'];
$quality = $_POST['quality'];
$unit = $_POST['unit'];
$sale_rate = $_POST['sale_rate'];
$gst_rate = $_POST['gst_rate'];
$remark = $_POST['remark'];
$ctime = date("Y-m-d H:i:s");
$product = new products;

$sql = $product->addProduct($name, $grade, $quality, $unit, $sale_rate, $gst_rate, $remark, $ctime);
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
echo $sql;
echo $conn->query($sql) ? 'successful' : 'failed';
header('location:products.php');
