<?php
$query = $_GET['q'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products";
$result = $conn->query($sql);
if (strlen($query) > 0) {
    while ($row = $result->fetch_assoc()) {

        if (preg_match("/$query/", $row['product_name'])) {
            echo "<div class='pro-line' onclick='add(this)' data-val='" . $row['product_id'] . "'><div class='name-btn'>" . $row['product_name'] . "</div><div class='grade-btn'>" . $row['grade'] . "</div><div class='quality-btn'>" . $row['quality'] . "</div></div>";
        }

    }
}
