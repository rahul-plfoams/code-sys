<?php
$product_id = $_GET['id'];
$sr = $_GET['sr'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products where product_id='$product_id'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()):
?>
<tr>
<td><?=$sr + 1?></td>
<td class=""><input type="text" name="products[]" value='<?=$row['product_name']?>' readonly>
<input type="hidden" name="product_id[]" value='<?=$row['product_id']?>'>
</td>
<td><?=$row['grade']?></td>
<td><?=$row['quality']?></td>
<td class=""><input type="number" name="rate[]" value='<?=$row['sale_rate']?>'></td>
<td class=""><?=$row['unit']?></td>
<td class=""><?=$row['gst_rate']?></td>
<td class=""><input type="text" name="remark[]" value='<?=$row['remark']?>'></td>

</tr>
<?php endwhile;?>