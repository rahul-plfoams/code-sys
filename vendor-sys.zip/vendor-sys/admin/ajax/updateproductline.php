<?php
$p_in = $_GET['p_in'];
$sr = $_GET['sr'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "UPDATE products SET product_rate='$product_id' ,product_remark=''";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()):
?>
<tr>
<td><?=$sr + 1?></td>
<td><input type="text" name="products[]" value='<?=$row['product_name']?>'>
<input type="hidden" name="product_id[]" value='<?=$row['product_id']?>'>
</td>
<td><?=$row['grade']?></td>
<td><?=$row['quality']?></td>
<td><input type="number" name="rate[]" value='<?=$row['sale_rate']?>'></td>
<td><?=$row['unit']?></td>
<td><?=$row['gst_rate']?></td>
<td><input type="text" name="remark[]" value='<?=$row['remark']?>'></td>

</tr>
<?php endwhile;?>