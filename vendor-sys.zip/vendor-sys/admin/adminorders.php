<?php
$orderid = $_GET['orderid'];
define("TITLE", "vendor");
require_once "./nav.php";

$sql = "SELECT * FROM orders WHERE order_id=" . $orderid;
$result = $db->query($sql)->fetch_assoc();
$orders = unserialize($result['order_details']);
?>
    <table id="listProducts" class="table table-bordered table-hover table-sm">
        <thead>
            <tr>
                <td class="justify-content-center p-2">Sr. No</td>
                <td class="iwidth">SKU/Code</td>
                <td>Name</td>
                <td>Grade</td>
                <td>Quality</td>
                <td>Unit</td>
                <td>Rate</td>
                <td>GST</td>
                <td>Length</td>
                <td>Width</td>
                <td>Thickness</td>
                <td>Quantity</td>
                <td>remark</td>
            </tr>
        </thead>
        <tbody id="ordertable">
        <?php for ($i = 0; $i < count($orders); $i++): ?>
        <tr>
            <td class="align-middle"><?=$i + 1?></td>
            <td class="align-middle"><?=$orders[$i]['vendor_code']?></td>
            <?php
$product = "SELECT * FROM vendor_pref INNER JOIN products using(product_id) WHERE vendor_id=" . $result['vendor_id'] . " AND product_id=" . $orders[$i]['product_id'];
$productdetails = $db->query($product)->fetch_assoc();
?>
            <td class="align-middle"><?=$productdetails['product_name']?>
            </td>
            <td class="align-middle"><?=$productdetails['grade']?></td>
            <td class="align-middle"><?=$productdetails['quality']?></td>
            <td class="align-middle"><?=$productdetails['unit']?></td>
            <td class="align-middle"><?=$productdetails['product_rate']?></td>
            <td class="align-middle"><?=$productdetails['gst_rate']?></td>
            <td class="align-middle"><?=$orders[$i]['length']?>
            </td>
            <td class="align-middle"><?=$orders[$i]['width']?>
            </td>
            <td class="align-middle"><?=$orders[$i]['thickness']?></td>
            <td class="align-middle"><?=$orders[$i]['quantity']?></td>
            <td class="align-middle"><?=$orders[$i]['remark']?></td>
            </tr>
        </tbody>

    <?php
endfor;
require_once "../footer.php";?>
