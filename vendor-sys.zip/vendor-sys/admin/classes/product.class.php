<?php
class Products
{
    private $name;
    private $grade;
    private $quality;
    private $unit;
    private $sale_rate;
    private $gst_rate;
    private $remark;

    public function addProduct($name, $grade, $quality, $unit, $sale_rate, $gst_rate, $remark)
    {

        $this->name = $name;
        $this->grade = $grade;
        $this->quality = $quality;
        $this->unit = $unit;
        $this->sale_rate = $sale_rate;
        $this->gst_rate = $gst_rate;
        $this->remark = $remark;
        return $sql = "INSERT INTO products (product_name,grade,quality,unit,sale_rate,gst_rate,remark) VALUES ('$this->name','$this->grade','$this->quality','$this->unit',$this->sale_rate,$this->gst_rate,'$this->remark')";

    }
    public function updateProduct($id, $name, $grade, $quality, $unit, $sale_rate, $gst_rate, $remark)
    {

        $this->name = $name;
        $this->grade = $grade;
        $this->quality = $quality;
        $this->unit = $unit;
        $this->sale_rate = $sale_rate;
        $this->gst_rate = $gst_rate;
        $this->remark = $remark;
        return $sql = "update products set product_name='$this->name',grade='$this->grade',quality='$this->quality',unit='$this->unit',sale_rate=$this->sale_rate,gst_rate=$this->gst_rate,remark='$this->remark' where product_id='$id'";

    }
    public function delete($id)
    {
        $conn = new mysqli('localhost', 'root', '', 'vendor_db');
        $sql = "DELETE FROM products WHERE product_id=$id";
        return $conn->query($sql);
    }
}
