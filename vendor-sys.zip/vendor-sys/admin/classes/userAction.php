<?php
// Start session
session_start();

// Include and initialize DB class
require_once 'db.class.php';
$db = new DB();

// Database table name
$tblName = 'vendor_details';

// Set default redirect url
$redirectURL = 'index.php';

if (isset($_POST['userSubmit'])) {
    // Get form fields value
    $name = trim(strip_tags($_POST['name']));
    $email = trim(strip_tags($_POST['email']));
    $phone = trim(strip_tags($_POST['phone']));

    // Fields validation
    $errorMsg = '';
    if (empty($name)) {
        $errorMsg .= '<p>Please enter your name.</p>';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMsg .= '<p>Please enter a valid email.</p>';
    }
    if (empty($phone) || !preg_match("/^[-+0-9]{6,20}$/", $phone)) {
        $errorMsg .= '<p>Please enter a valid phone number.</p>';
    }

    // Submitted form data
    $userData = array(
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
    );

    // Store the submitted field value in the session
    $sessData['userData'] = $userData;

    // Submit the form data
    if (empty($errorMsg)) {
        if (!empty($_POST['id'])) {
            // Update user data
            $condition = array('id' => $_POST['id']);
            $update = $db->update($tblName, $userData, $condition);

            if ($update) {
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'User data has been updated successfully.';

                // Remote submitted fields value from session
                unset($sessData['userData']);
            } else {
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Some problem occurred, please try again.';

                // Set redirect url
                $redirectURL = 'addEdit.php';
            }
        } else {
            // Insert user data
            $insert = $db->insert($tblName, $userData);

            if ($insert) {
                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'User data has been added successfully.';

                // Remote submitted fields value from session
                unset($sessData['userData']);
            } else {
                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Some problem occurred, please try again.';

                // Set redirect url
                $redirectURL = 'addEdit.php';
            }
        }
    } else {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = '<p>Please fill all the mandatory fields.</p>' . $errorMsg;

        // Set redirect url
        $redirectURL = 'addEdit.php';
    }

    // Store status into the session
    $_SESSION['sessData'] = $sessData;
} elseif (($_REQUEST['action_type'] == 'delete') && !empty($_GET['id'])) {
    // Delete data
    $condition = array('id' => $_GET['id']);
    $delete = $db->delete($tblName, $condition);

    if ($delete) {
        $sessData['status']['type'] = 'success';
        $sessData['status']['msg'] = 'User data has been deleted successfully.';
    } else {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'Some problem occurred, please try again.';
    }

    // Store status into the session
    $_SESSION['sessData'] = $sessData;
}

if (isset($_POST['update'])) {

        $fn = $_POST['fname'];
        $ln = $_POST['lname'];
        $name = $_POST['name'];
        $company_name = $_POST['company_name'];
        $password_1 = $_POST['password_1'];
        $password = md5($password_1); //encrypt the password before saving in the database
    
        $address = $_POST['address'];
        $place = $_POST['place'];
        $pincode = $_POST['pincode'];
        $state = $_POST['state'];
        $country = $_POST['country'];
        $credit_days = $_POST['credit_days'];
        $credit_limit = $_POST['credit_limit'];
        $kilometer = $_POST['kilometer'];
    
        $billing_address = $_POST['billing_address'];
        $billing_place = $_POST['billing_place'];
        $billing_pincode = $_POST['billing_pincode'];
        $billing_state = $_POST['billing_state'];
        $billing_country = $_POST['billing_country'];
        $billing_credit_days = $_POST['billing_credit_days'];
        $billing_credit_limit = $_POST['billing_credit_limit'];
        $billing_kilometer = $_POST['billing_kilometer'];
    
        $phone = $_POST['phone'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $website = $_POST['website'];
        $reference = $_POST['reference'];
        $owner = $_POST['owner'];
        $gst_place = $_POST['gst_place'];
        $state_code = $_POST['state_code'];
        $gst_no = $_POST['gst_no'];
        $account_no = $_POST['account_no'];
        $bank_name = $_POST['bank_name'];
        $account_type = $_POST['account_type'];
        $ifsc = $_POST['ifsc'];
        $branch = $_POST['branch'];
    
    //     $insert = "UPDATE users set username = '$fn', user_type = '$ln', name = '$name', password = '$password' where id = '$id'";
    
    //     $insert1 = "UPDATE vendor_details SET company_name = '" . $company_name . "', address = '" . $address . "', place = '" . $place . "', pincode = '" . $pincode . "', state = '" . $state . "', country = '" . $country . "', credit_days = '" . $credit_days . "', credit_limit = '" . $credit_limit . "', kilometer = '" . $kilometer . "', billing_address = '" . $billing_address . "', billing_place = '" . $billing_place . "', billing_pincode = '" . $billing_pincode . "', billing_state = '" . $billing_state . "', billing_country = '" . $billing_country . "', billing_credit_days = '" . $billing_credit_days . "', billing_credit_limit = '" . $billing_credit_limit . "', billing_kilometer = '" . $billing_kilometer . "', phone = '" . $phone . "', mobile = '" . $mobile . "', email = '" . $email . "', website = '" . $website . "', reference = '" . $reference . "', owner = '" . $owner . "', gst_place = '" . $gst_place . "', state_code = '" . $state_code . "', gst_no = '" . $gst_no . "', account_no = '" . $account_no . "', bank_name = '" . $bank_name . "', account_type = '" . $account_type . "', ifsc = '" . $ifsc . "', branch = '" . $branch . "', where id='" . $id . "'";
    
    //     if ($conn->query($insert) && $conn->query($insert1)) {
    
    //         $_SESSION['msg'] = "Saved successfully";
    //         header('location:edit.php?id=' . $id);
    //     } else {
    //         $_SESSION['msg'] = "";
    //         echo "Ooppss cannot add data" . $conn->error;
    //         header('location:home.php');
    //     }
    
    //     $conn->close();
    // }

// Redirect to the respective page
header("Location:" . $redirectURL);
exit();
    }