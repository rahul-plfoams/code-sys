<?php
$p_in = $_GET['pid'];
$vendor_id = $_GET['id'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$p_in . '<br>';
$vendor_id . '<br>';
$conn->query("DELETE FROM vendor_pref WHERE p_in=$p_in") ? 'success' : 'failed';
header("location:edit.php?id=$vendor_id");
