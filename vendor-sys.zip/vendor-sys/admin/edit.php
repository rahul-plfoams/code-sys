<?php
define("TITLE", "Vendor info");
require_once "./nav.php";
$id = $_GET['id'];
$details = "SELECT * FROM users JOIN vendor_details USING(id) WHERE id=$id";
$details_result = $db->query($details)->fetch_assoc();
?>
<div class="container mt--7">
	<div class="card">
		<div class="card-header">
			<div class="d-flex">
				Overview
			</div>
		</div>
		<div class="card-body">
			<p class="card-text">
				<?php $viewname = "SELECT * from users where id = '$id'";
$get_outstanding = 'SELECT sum(credit - debit) from ledger_data where id=' . $id;
$outstanding = $db->query($get_outstanding);?>
				Name: <?=$result = $db->query($viewname)->fetch_assoc()['name']?><br>
				Company Name:<?=$details_result['company_name']?><br>
				Total Outstanding:<?=$outstanding->fetch_assoc()['sum(credit - debit)']?>
			</p>
			<!-- Nav tabs -->
			<ul class="nav nav-tabs nav-justified" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#overview">Overview</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#billing">Billing</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#shipping">Shipping</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#contact">Contact/Ref</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#gst">GST/Bank</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#ledger">Ledger</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#products">Items / Goods</a>
				</li>
			</ul>
			<!-- Tab panes -->
			<div class="tab-content">
				<!-- <form id="frm1" action="" method="POST"> -->
				<div id="overview" class="container tab-pane active">
					<form action="updateuser.php" method="post" id="frm1">
						<div class="form-group row">
							<label for="company_name" class="col-sm-2 col-form-label">Company Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="company_name" name="company_name"
									value="<?=$details_result['company_name'];?>"
									placeholder="Type company name here..">
							</div>
						</div>
						<div class="form-group row">
							<label for="name" class="col-sm-2 col-form-label">Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="name" name="name"
									value="<?=$details_result['name'];?>" placeholder="Type company name here..">
							</div>
						</div>
						<div class="form-group row">
							<label for="mobile" class="col-sm-2 col-form-label">Mobile</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="mobile" name="mobile"
									value="<?=$details_result['mobile'];?>" placeholder="Type company name here..">
							</div>
						</div>
						<div class="form-group row">
							<label for="role" class="col-sm-2 col-form-label">Role</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="" name="role"
									value="<?=$details_result['user_type'];?>" placeholder="Type company name here..">
							</div>
						</div>
						<div class="btn-grp">
							<button id="toggleEdit" class="btn btn-dark button btnPush btnBlueGreen"
								type="button">Edit</button>
							<button class="btn btn-success button btnPush btnBlueGreen" type="submit" name="update"
								disabled>Save</button>
						</div>
					</form>
				</div>
				<div id="billing" class="container tab-pane fade">
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="billing_country" class="col-form-label">country</label>
							<input type="text" class="form-control" name="billing_country" id="billing_country"
								value="<?=$details_result['billing_country'];?>" placeholder="Type country here..">
						</div>
						<div class="col-sm-4">
							<label for="billing_state" class=" col-form-label">State</label>
							<input type="text" class="form-control" name="billing_state" id="billing_state"
								value="<?=$details_result['billing_state'];?>" placeholder="Type state here..">
						</div>
						<div class="col-sm-4">
							<label for="billing_city" class="col-form-label">city</label>
							<input type="text" class="form-control" name="billing_city" id="billing_city"
								value="<?=$details_result['billing_city'];?>" placeholder="Type city here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-8">
							<label for="billing_address" class=" col-form-label">Address</label>
							<input type="text" class="form-control" id="billing_address" name="billing_address"
								value="<?=$details_result['billing_address'];?>" placeholder="Type address here..">
						</div>
						<div class="col-sm-4">
							<label for="billing_pincode" class=" col-form-label">Pincode</label>
							<input type="text" class="form-control" id="billing_pincode" name="billing_pincode"
								value="<?=$details_result['billing_pincode'];?>" placeholder="Type address here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="billing_credit_limit" class="col-form-label">Credit Limit</label>
							<input type="text" class="form-control" id="billing_credit_limit"
								name="billing_credit_limit" value="<?=$details_result['billing_credit_limit'];?>"
								placeholder="Type credit limit here..">
						</div>
						<div class="col-sm-4">
							<label for="billing_credit_days" class="col-form-label">Credit days</label>
							<input type="text" class="form-control" id="billing_credit_days" name="billing_credit_days"
								value="<?=$details_result['billing_credit_days'];?>"
								placeholder="Type credit days here..">
						</div>
						<div class="col-sm-4">
							<label for="billing_kilometer" class="col-form-label">Distance</label>
							<input type="text" class="form-control" id="billing_kilometer" name="billing_kilometer"
								value="<?=$details_result['billing_kilometer'];?>" placeholder="Type kilometer here..">
						</div>
					</div>
				</div>
				<div id="shipping" class="container tab-pane fade">
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="country" class="col-form-label">country</label>
							<input type="text" class="form-control" name="country" id="country"
								value="<?=$details_result['country'];?>" placeholder="Type country here..">
						</div>
						<div class="col-sm-4">
							<label for="state" class="col-form-label">State</label>
							<input type="text" class="form-control" name="state" id="state"
								value="<?=$details_result['state'];?>" placeholder="Type state here..">
						</div>
						<div class="col-sm-4">
							<label for="city" class="col-form-label">city</label>
							<input type="text" class="form-control" name="city" id="city"
								value="<?=$details_result['city'];?>" placeholder="Type city here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-8">
							<label for="address" class=" col-form-label">Address</label>
							<input type="text" class="form-control" id="address" name="address"
								value="<?=$details_result['address'];?>" placeholder="Type address here..">
						</div>
						<div class="col-sm-4">
							<label for="pincode" class=" col-form-label">Pincode</label>
							<input type="text" class="form-control" id="pincode" name="pincode"
								value="<?=$details_result['pincode'];?>" placeholder="Type address here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="credit_limit" class=" col-form-label">Credit Limit</label>
							<input type="text" class="form-control" id="credit_limit" name="credit_limit"
								value="<?=$details_result['credit_limit'];?>" placeholder="Type credit limit here..">
						</div>
						<div class="col-sm-4">
							<label for="credit_days" class=" col-form-label">Credit days</label>
							<input type="text" class="form-control" id="credit_days" name="credit_days"
								value="<?=$details_result['credit_days'];?>" placeholder="Type credit days here..">
						</div>
						<div class="col-sm-4">
							<label for="kilometer" class=" col-form-label">Distance</label>
							<input type="text" class="form-control" id="kilometer" name="kilometer"
								value="<?=$details_result['kilometer'];?>" placeholder="Type kilometer here..">
						</div>
					</div>
				</div>
				<div id="contact" class="container tab-pane fade">
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="mobile" class=" col-form-label">Mobile</label>
							<input type="text" class="form-control" id="mobile" name="mobile"
								value="<?=$details_result['mobile'];?>" placeholder="Type mobile here..">
						</div>
						<div class="col-sm-4">
							<label for="email" class=" col-form-label">Email</label>
							<input type="text" class="form-control" id="email" name="email"
								value="<?=$details_result['email'];?>" placeholder="Type email here..">
						</div>
						<div class="col-sm-4">
							<label for="phone" class="col-form-label">Phone</label>
							<input type="text" class="form-control" id="phone" name="phone"
								value="<?=$details_result['phone'];?>" placeholder="Type Phone here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-8">
							<label for="website" class=" col-form-label">Website</label>
							<input type="text" class="form-control" id="website" name="website"
								value="<?=$details_result['website'];?>" placeholder="Type website here..">
						</div>
						<div class="col-sm-4">
							<label for="reference" class=" col-form-label">Reference</label>
							<input type="text" class="form-control" id="reference" name="reference"
								value="<?=$details_result['reference'];?>" placeholder="Type reference here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-12">
							<label for="owner" class=" col-form-label">Owner</label>
							<input type="text" class="form-control" id="owner" name="owner"
								value="<?=$details_result['owner'];?>" placeholder="Type owner here..">
						</div>
					</div>
				</div>
				<div id="gst" class="container tab-pane fade">
					<div class="form-group row">
						<div class="col-sm-4">
							<label for="gst_place" class=" col-form-label">GST place</label>
							<input type="text" class="form-control" id="gst_place" name="gst_place"
								value="<?=$details_result['gst_place'];?>" placeholder="Type gst_place here..">
						</div>
						<div class="col-sm-4">
							<label for="state_code" class=" col-form-label">state code</label>
							<input type="text" class="form-control" id="state_code" name="state_code"
								value="<?=$details_result['state_code'];?>" placeholder="Type state_code here..">
						</div>
						<div class="col-sm-4">
							<label for="gst_no" class=" col-form-label">GST No</label>
							<input type="text" class="form-control" id="gst_no" name="gst_no"
								value="<?=$details_result['gst_no'];?>" placeholder="Type gst_no here..P">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-6">
							<label for="owner" class=" col-form-label">A/C Holder Name</label>
							<input type="text" class="form-control" id="owner" name="owner"
								value="<?=$details_result['owner'];?>" placeholder="Type owner here..">
						</div>
						<div class="col-sm-6">
							<label for="account_no" class=" col-form-label">Permanent A/c no.</label>
							<input type="text" class="form-control" id="account_no" name="account_no"
								value="<?=$details_result['account_no'];?>" placeholder="Type account_no here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-6">
							<label for="bank_name" class=" col-form-label">Bank Name</label>
							<input type="text" class="form-control" id="bank_name" name="bank_name"
								value="<?=$details_result['bank_name'];?>" placeholder="Type bank_name here..">
						</div>
						<div class="col-sm-6">
							<label for="account_type" class=" col-form-label">A/C Type</label>
							<input type="text" class="form-control" id="account_type" name="account_type"
								value="<?=$details_result['account_type'];?>" placeholder="Type account_type here..">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-sm-6">
							<label for="branch" class=" col-form-label">Branch</label>
							<input type="text" class="form-control" id="branch" name="branch"
								value="<?=$details_result['branch'];?>" placeholder="Type branch here..">
						</div>
						<div class="col-sm-6">
							<label for="ifsc" class=" col-form-label">IFSC</label>
							<input type="text" class="form-control" id="ifsc" name="ifsc"
								value="<?=$details_result['ifsc'];?>" placeholder="Type ifsc here..">
						</div>
					</div>
				</div>
				<!-- </form> -->
				<div id="ledger" class="container tab-pane fade">
					<div id="importFrm">
						<form action="importdata.php?id=<?=$id;?>" method="post" enctype="multipart/form-data">
							<table class="table table-bordered customers">
								<tbody>
									<tr>
										<td class="chooseFileTd">
											<input class="chooseFileInput" type="file" name="file" />
											<input type="submit" class="btn btn-primary" name="importSubmit"
												value="IMPORT">
										</td>
									</tr>
								</tbody>
							</table>
						</form>
						<?php
$get_outstanding = 'SELECT sum(credit - debit) from ledger_data where id=' . $id;
$outstanding = $db->query($get_outstanding);
echo 'Outstanding Balance: ' . $outstanding->fetch_assoc()['sum(credit - debit)'] . ' Rs';
// pagination starts----------
$limit = 10; // Number of entries to show in a page.
// Look for a GET variable page if not found default is 1.
if (isset($_GET["page"])) {
    $pn = $_GET["page"];
} else {
    $pn = 1;
}
$start_from = ($pn - 1) * $limit;
$get_details = "select * from ledger_data where id=$id LIMIT $start_from, $limit";
$result = $db->query($get_details); ///pagination database query         ?>
						<table id=" customers" class="unfiltered table table-bordered ">
							<tr>
								<th>date</th>
								<th>particulars</th>
								<th>remark</th>
								<th>voucher_type</th>
								<th>voucher_no</th>
								<th>debit</th>
								<th>credit</th>
							</tr>
							<?php while ($details_result = $result->fetch_assoc()): ?>
							<tr>
								<td class="align-middle"><?=$details_result["date"]?></td>
								<td class="align-middle"><?=$details_result["particulars"]?></td>
								<td class="align-middle"><?=$details_result["remark"]?></td>
								<td class="align-middle"><?=$details_result["voucher_type"]?></td>
								<td class="align-middle"><?=$details_result["voucher_no"]?></td>
								<td class="align-middle"><?=$details_result["debit"]?></td>
								<td class="align-middle"><?=$details_result["credit"]?></td>
							</tr>
							<?php endwhile;?>
						</table>
						<!-- pagination list -->
						<ul class="pagination">
							<?php
$sql = "SELECT * FROM ledger_data where id=$id";
$rs_result = $db->query($sql);
$total_records = mysqli_num_rows($rs_result);
// Number of pages required.
$total_pages = ceil($total_records / $limit);
$pagLink = "";
for ($i = 1; $i <= $total_pages; $i++) {
    if ($i == $pn) {
        $pagLink .= "<li class='active'><a href='edit.php?id=" . $id . "&page="
            . $i . "'>" . $i . "</a></li>";
    } else {
        $pagLink .= "<li><a href='edit.php?id=$id&page=$i'>$i</a></li>";
    }
}
echo $pagLink;
?>
						</ul>
						--------------------------
						<!-- pagination end -->
					</div>
				</div>
				<div id="products" class="container tab-pane fade row">
					<?php
$vendor_id = $_GET['id'];
$sql = "select * from products";
$result = $db->query($sql);
?>
					<div class="col-lg-12">
						<form>
							<div class="form-group row">
								<div class="col-lg-5 mx-auto mt-4">
									<input type="text" size="30" placeholder="search product here..."
										class="searching form-control" onkeyup="showResult(this.value)">
								</div>
							</div>
							<div class="form-group row">
								<div class="col">
									<div id="livesearch">
									</div>
								</div>
							</div>
						</form>
					</div>
					<form action="storePref.php?id=<?=$vendor_id?>" method="post">
						<table class="table table-bordered text-center">
							<thead>
								<tr>
									<td class="align-middle">Sr. No</td>
									<td class="align-middle">Name</td>
									<td class="align-middle">Grade</td>
									<td class="align-middle">Quality</td>
									<td class="align-middle">Rate</td>
									<td class="align-middle">Unit</td>
									<td class="align-middle">GST</td>
									<td class="align-middle">remark</td>
								</tr>
							</thead>
							<tbody id="showProduct">
							</tbody>
						</table>
						<div class="row1 p-1">
							<button class="btn btn-success" type="submit">Save</button>
						</div>
					</form>
					<table id="listProducts" class="table table-bordered text-center">
						<thead>
							<tr>
								<td class="align-middle">Sr. No</td>
								<td class="align-middle">Name</td>
								<td class="align-middle">Grade</td>
								<td class="align-middle">Quality</td>
								<td class="align-middle">Rate</td>
								<td class="align-middle">Unit</td>
								<td class="align-middle">GST</td>
								<td class="align-middle">remark</td>
								<td class="align-middle">actions</td>
							</tr>
						</thead>
						<tbody>
							<?php
$sql_res = "SELECT * FROM vendor_pref JOIN products using(product_id) where vendor_id=$vendor_id";
$tabres = $db->query($sql_res);
$tsr = 1;
while ($tabrow = $tabres->fetch_assoc()):
?>
							<tr>
								<td class="align-middle"><?=$tsr;?></td>
								<td class="align-middle"><?=$tabrow['product_name']?></td>
								<td class="align-middle"><?=$tabrow['grade']?></td>
								<td class="align-middle"><?=$tabrow['quality']?></td>
								<td class="align-middle"><?=$tabrow['product_rate']?></td>
								<td class="align-middle"><?=$tabrow['unit']?></td>
								<td class="align-middle"><?=$tabrow['gst_rate']?></td>
								<td class="align-middle p-0"><?=$tabrow['product_remark']?><span
										style="color:grey;float:right"> (<?php
if ($tabrow['modified_date'] === null) {
    echo $tabrow['added_date'];
} else {
    echo $tabrow['modified_date'];
}
?>)</span></td>
								<td class="align-middle">
									<a class="btn btn-info" onclick="editVendorProduct(this)" href="#"
										data-p_in="<?=$tabrow['p_in']?>">Edit</a>
									<a class="btn btn-danger"
										href="delProduct.php?id=<?=$vendor_id?>&pid=<?=$tabrow['p_in']?>">delete</a>
								</td>
							</tr>
							<?php $tsr++;
endwhile;?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- The Modal -->
<div id="myModal" class="modal">
	<!-- Modal content -->
	<div class="modal-content">
		<div class="modal-header">
			<span class="close">&times;</span>
			<h2 id="editProductName">demo</h2>
		</div>
		<div class="modal-body">
			<form action="" method="post" onsubmit="editVendorProduct(this); return false;">
				<label for="editProductRate">Rate</label>
				<input type="number" name="" id="editProductRate">
				<label for="editProductRemark">Remark</label>
				<input type="Text" name="" id="editProductRemark">
				<input type="submit" value="save" onclick="">
			</form>
		</div>
	</div>
</div>
<?php require_once "../footer.php"?>
<script src="../js/edit.js"></script>
<script>
	$(document).ready(function () {
		$(".nav-tabs a").click(function () {
			$(this).tab('show');
		});
		$('.nav-tabs a').on('shown.bs.tab', function (event) {
			var x = $(event.target).text();
			var y = $(event.relatedTarget).text();
			$(".act span").text(x);
			$(".prev span").text(y);
		});
	});
</script>