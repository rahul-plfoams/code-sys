<?php
date_default_timezone_set('Asia/Kolkata');
$vendor_id = $_GET['id'];
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
// $sqlproduct = "select * from products";
// $sqlpref = "select * from vendor_pref";
// $result = $conn->query($sql);

$products = $_POST['products'];
$rate = $_POST['rate'];
$remark = $_POST['remark'];
$product_id = $_POST['product_id'];
$date = date('Y-m-d H:i:s');

for ($i = 0; $i < count($products); $i++) {
    $sql = "INSERT INTO vendor_pref (vendor_id,product_id,product_rate,product_remark,added_date) VALUES ($vendor_id,$product_id[$i],'$rate[$i]','$remark[$i]','$date')";
    $conn->query($sql) ? 'success' : 'failed';
}
header("location:edit.php?id=$vendor_id");
