<?php
define("TITLE", "update user info");
require_once "./nav.php";
// $details = "SELECT * FROM users JOIN vendor_details USING(id)";
// $db->query($details)->fetch_assoc()['mobile'];

// if (isset($_POST['update'])) {
//     $fn = $_POST['fname'];
//     $ln = $_POST['lname'];
//     $name = $_POST['name'];
//     $company_name = $_POST['company_name'];
//     $address = $_POST['address'];
//     $place = $_POST['place'];
//     $pincode = $_POST['pincode'];
//     $state = $_POST['state'];
//     $country = $_POST['country'];
//     $credit_days = $_POST['credit_days'];
//     $credit_limit = $_POST['credit_limit'];
//     $kilometer = $_POST['kilometer'];
//     $billing_address = $_POST['billing_address'];
//     $billing_place = $_POST['billing_place'];
//     $billing_pincode = $_POST['billing_pincode'];
//     $billing_state = $_POST['billing_state'];
//     $billing_country = $_POST['billing_country'];
//     $billing_credit_days = $_POST['billing_credit_days'];
//     $billing_credit_limit = $_POST['billing_credit_limit'];
//     $billing_kilometer = $_POST['billing_kilometer'];
//     $phone = $_POST['phone'];
//     $mobile = $_POST['mobile'];
//     $email = $_POST['email'];
//     $website = $_POST['website'];
//     $reference = $_POST['reference'];
//     $owner = $_POST['owner'];
//     $gst_place = $_POST['gst_place'];
//     $state_code = $_POST['state_code'];
//     $gst_no = $_POST['gst_no'];
//     $account_no = $_POST['account_no'];
//     $bank_name = $_POST['bank_name'];
//     $account_type = $_POST['account_type'];
//     $ifsc = $_POST['ifsc'];
//     $branch = $_POST['branch'];
//     $vendor = $id;
//     $insert = "UPDATE users set username = '$fn', user_type = '$ln', name = '$name' where id = $id";
//     $insert1 = "UPDATE vendor_details SET company_name = ' $company_name ', address = ' $address ', place = ' $place ', pincode = ' $pincode ', state = ' $state ', country = ' $country ', credit_days = ' $credit_days ', credit_limit = ' $credit_limit ', kilometer = ' $kilometer ', billing_address = ' $billing_address ', billing_place = ' $billing_place ', billing_pincode = ' $billing_pincode ', billing_state = ' $billing_state ', billing_country = ' $billing_country ', billing_credit_days = ' $billing_credit_days ', billing_credit_limit = ' $billing_credit_limit ', billing_kilometer = ' $billing_kilometer ', phone = ' $phone ', mobile = ' $mobile ', email = ' $email ', website = ' $website ', reference = ' $reference ', owner = ' $owner ', gst_place = ' $gst_place ', state_code = ' $state_code ', gst_no = ' $gst_no ', account_no = ' $account_no ', bank_name = ' $bank_name ', account_type = ' $account_type ', ifsc = ' $ifsc ', branch = ' $branch ', where id=$id";
//     if ($db->query($insert) && $db->query($insert1)) {
//         $_SESSION['msg'] = "Saved successfully";
//         header("location:edit.php?id=$id");
//     } else {
//         $_SESSION['msg'] = "";
//         echo "Ooppss cannot add data" . $db->error;
//         // header('location:home.php');
//         // header('location:edit.php?id=' . $id);
//     }
// }
$date = date("Y-m-d H:i:s");
$userData = [
    'username' => '3',
    'email' => '3',
    'user_type' => '3',
    'password' => '3',
    'name' => '3',
    'user_added' => "$date",
];

$condition = array('id' => 2);
$db = new database;
// var_dump($db->getRows('vendor_details', $condition));
// var_dump($userData);
var_dump($GLOBALS);
// var_dump($db->insert('users', $userData));
