<?php
include '../classes/product.class.php';
$id = $_GET['id'];
$del = new products;
echo $del->delete($id) ? 'success' : 'failed';
header('location:products.php');
