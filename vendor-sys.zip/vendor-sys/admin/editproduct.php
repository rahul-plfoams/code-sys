
<link rel="stylesheet" type="text/css" href="../sass/style.css">
<form class="section is-centered columns" action="updateProducts.php" method="post">
  <div class="field column">
    <label class="label">name</label>
    <input class="input" type="text" name="name" placeholder="name"/>
  </div>
  <div class="field column">
    <label class="label">Grade</label>
    <input class="input" type="text" name="grade" placeholder="Product Grade"/>
  </div>
  <div class="field column">
    <label class="label">Quality</label>
    <input class="input" type="text" name="quality" placeholder="Product Quality"/>
  </div>
  <div class="field column">
    <label class="label">Sale Rate</label>
    <input class="input" type="text" name="sale_rate" placeholder="Product Price"/>
  </div>
  <div class="field column">
    <label class="label">GST Rate</label>
    <input class="input" type="text" name="gst_rate" placeholder="GST Rate"/>
  </div>
  <div class="field column">
    <label class="label">Remark</label>
    <input class="input" type="text" name="remark" placeholder="Remark/Specification"/>
  </div>
  <div class="field column">
    <label class="is-centered label">unit</label>
    <div class="select">
      <select name="unit">
        <option>mm</option>
        <option>kg</option>
        <option>Sq. feet</option>
        <option>pcs</option>
        <option>m</option>
      </select>
    </div>
  </div>
  <div class="field is-grouped column">
    <div class="control">
      <button class="button is-link" value="Save">Save</button>
    </div>
    <div class="control">
      <button class="button is-text">Cancel</button>
    </div>
  </div>
</form>