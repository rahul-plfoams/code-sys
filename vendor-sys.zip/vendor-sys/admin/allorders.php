<?php
define("TITLE", "admin");
require_once "nav.php";

$sql = "SELECT * FROM orders";
// $product = "SELECT * FROM vendor_pref INNER JOIN products using(product_id) WHERE vendor_id=" . $_SESSION['user']['id'];
$result = $db->query($sql);
?>
<form action="" method="post">
    <table id="listProducts" class="table table-bordered table-hover table-sm text-center">
        <thead>
            <tr>
                <td>Order No</td>
                <td>Vendor</td>
                <td>Status</td>
                <td>Time</td>
                <td>Action</td>
            </tr>
        </thead>
        <tbody id="ordertable">
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr class="">
<td><?=$row['order_id'];?></td>
<?php $product = "SELECT * FROM vendor_pref INNER JOIN users ON vendor_pref.vendor_id=users.id WHERE vendor_id=" . $row['vendor_id'];
$vendor = $db->query($product)->fetch_assoc()['name'];
?>
<td><?=$vendor;?></td>
<td><?=$row['order_status'];?></td>
<td><?=$row['order_generated']?></td>
<td><a class="btn btn-info" href="adminorders.php?orderid=<?=$row['order_id'];?>">Check</a><button class="btn btn-dark">Update</button></td>
</tr>
        <?php endwhile;?>
        </tbody>
    </table>



<!-- Footer -->
<?php include "../footer.php"?>