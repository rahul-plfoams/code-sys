<?php
define("TITLE", "admin");
require_once "nav.php";?>
  <div class="container-fluid mt--7">
    <div class="row">
      <div class="col-xl-4 mb-5 mb-xl-0">
        <div class="card bg-gradient-default shadow">
          <div class="card-header bg-transparent">
            <div class="row align-items-center">
              <div class="col">
                <h2 class="text-uppercase text-light ls-1 mb-1">Create Account</h6>
              </div>
            </div>
          </div>
          <div class="card-body pt-0">
            <form action="./create_user.php" method="POST">
              <div class="">
                <div class="row">
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">Name</label>
                      <input type="text" name="name" value="" placeholder="Type name here" required
                        class="form-control form-control-alternative">
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">Mobile
                        No:</label>
                      <input type="text" name="mobile" value="" placeholder="Type mobile here" required
                        class="form-control form-control-alternative">
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">User
                        Type:</label>
                      <select name="user_type" class="form-control">
                        <option value="admin">Admin</option>
                        <option value="user" selected>Vendor</option>
                        <option value="staff">Staff</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">Email:</label>
                      <input type="text" name="email" value="" placeholder="Type Email here" required
                        class="form-control form-control-alternative">
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">Password:</label>
                      <input type="text" name="password_1" placeholder="Type Password here.." required
                        class="form-control form-control-alternative">
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class=""><label for="" class="form-control-label text-white">Confirm
                        Password:</label>
                      <input type="text" name="password_2" placeholder="Repeat Password here.."
                        class="form-control form-control-alternative">
                    </div>
                  </div>
                  <div class="col-lg-12 pt-2">
                    <div class="row">
                      <div class="col-lg-6">
                        <button type="submit" name="add" class="btn btn-success">Add</button>
                      </div>
                      <div class="col-lg-6">
                        <button type="reset" name="add" class="btn btn-danger">Clear</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
        </form>
      </div>
      <div class="col-xl-8">
        <div class="card shadow">
          <div class="card-header bg-transparent">
            <div class="row align-items-center">
              <div class="col">
                <h2 class="mb-0">Vendors/Staff</h2>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <div>
                <table class="table align-items-center">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col">Name</th>
                      <th scope="col">Mobile No</th>
                      <th scope="col">Role</th>
                      <th scope="col">Action</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <?php
$sql = "SELECT * FROM users JOIN vendor_details USING(id)";
$result = $db->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        ?>
                  <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['mobile']; ?></td>
                    <td><?php echo $row['user_type']; ?></td>
                    <td>
                      <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                      /
                      <a href="delete.php?id=<?php echo md5($row['id']); ?>">Delete</a>
                    </td>
                    <td onclick="statuschange();"><?php
$vsql = "select * from vendor_details where id= " . $row['id'];
        $status = $db->query($vsql)->fetch_assoc();
        switch ($status['status']) {
          case 0:
                echo 'disabled';
                break;
            case 1:
                echo 'enabled';
                break;
            default:
                echo 'status not set';}
        ?></td>
                  </tr>
                  <?php
}
} else {
    echo "<center><p> No Records</p></center>";
}
?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!-- Footer -->
  <?php include "../footer.php"?>

<script src="../js/home.js"></script>