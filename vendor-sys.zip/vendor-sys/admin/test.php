
<select name="product">
<?php
$connection = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products";
$result = $connection->query($sql);
while ($row = $result->fetch_assoc()):
?>
    <option value=""><?=$row['product_name']?></option>
    <?php endwhile;?>
</select>
<button onclick="getProduct()">add</button>
<div id="showProduct">


</div>
<script>

function getProduct(){
	const sel=document.querySelector('select');
	str=sel.options[sel.selectedIndex].text;
	xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("showProduct").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","ajax/addproductline.php?q="+str,true);
        xmlhttp.send();
}
</script>