<?php
define("TITLE", "Master Products");
require_once "nav.php"?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css"/>
<form class="section is-centered columns" action="saveProducts.php" method="post">
  <div class="field column">
    <label class="label">name</label>
    <input class="input" type="text" name="name" placeholder="Product Name"/>
  </div>
  <div class="field column">
    <label class="label">Grade</label>
    <input class="input" type="text" name="grade" placeholder="Product Grade"/>
  </div>
  <div class="field column">
    <label class="label">Quality</label>
    <input class="input" type="text" name="quality" placeholder="Product Quality"/>
  </div>
  <div class="field column">
    <label class="label">Sale Rate</label>
    <input class="input" type="text" name="sale_rate" placeholder="Product Price"/>
  </div>
  <div class="field column">
    <label class="label">GST Rate</label>
    <input class="input" type="text" name="gst_rate" placeholder="GST Rate"/>
  </div>
  <div class="field column">
    <label class="label">Remark</label>
    <input class="input" type="text" name="remark" placeholder="Remark/Specification"/>
  </div>
  <div class="field column">
    <label class="is-centered label">unit</label>
    <div class="select">
      <select name="unit">
      <option>mm</option>
        <option>kg</option>
        <option>Sq.Ft</option>
        <option>Pcs</option>
        <option>Meter</option>
      </select>
    </div>
  </div>
  <div class="field is-grouped column">
    <div class="control">
      <button class="button is-link" value="Save">Save</button>
    </div>
    <div class="control">
      <button class="button is-danger">Cancel</button>
    </div>
    <div class="control">
    <a href="home.php" class="button is-success">Home</a>
    </div>
  </div>
</form>
<table class="table is-bordered is-fullwidth">
  <thead>
    <tr>
      <td>ID</td>
      <td>Name</td>
      <td>Grade</td>
      <td>Quality</td>
      <td>Unit</td>
      <td>Sale Rate</td>
      <td>GST Rate</td>
      <td>Remark</td>
      <td>Edit</td>
    </tr>
  </thead>
  <tbody>
    <?php
$conn = new mysqli('localhost', 'root', '', 'vendor_db');
$sql = "select * from products";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()): ?>
        <tr>
        <td><?=$row['product_id']?></td>
        <td><?=$row['product_name']?></td>
        <td><?=$row['grade']?></td>
        <td><?=$row['quality']?></td>
        <td><?=$row['unit']?></td>
        <td><?=$row['sale_rate']?></td>
        <td><?=$row['gst_rate']?></td>
        <td><?=$row['remark']?> <span style="color:grey;float:right">(<?=$row['master_added']?>)</span></spam></td>
        <td><a href='editproducts.php?id=<?=$row['product_id']?>'>edit</a>
        <!-- <a style='color:red' href='deleteproducts.php?id=<?=$row['product_id']?>'>delete</a> -->
        <a style='color:red' href=''>delete</a>
        </td>
        </tr>

<?php endwhile;?>
  </tbody>
</table>
<?php include_once "../footer.php"?>