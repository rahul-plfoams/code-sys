<?php
spl_autoload_register('load');
function load($class)
{
    if (file_exists("./classes/$class.class.php")) {
        require_once "./classes/$class.class.php";
    } else {
        require_once "../classes/$class.class.php";
    }
}
